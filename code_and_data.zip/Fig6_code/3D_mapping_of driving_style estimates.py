import numpy as np
import matplotlib.pyplot as plt
from matplotlib import font_manager
from mpl_toolkits.mplot3d import Axes3D
import pandas as pd


filename = 'driving_style_data.csv'
data = pd.read_csv(filename)
driving_style_probabilities = data.loc[:, ['Vehicle_ID', 'v_Vel', 'v_Acc','Time_Hdwy']]


duration = 3600
interval = 60
conservative_tendency = 0.1
initial_estimation = [0.3, 0.3, 0.4]


aggressive_probabilities = [p[0] for p in driving_style_probabilities]
general_probabilities = [p[1] for p in driving_style_probabilities]
conservative_probabilities = [p[2] for p in driving_style_probabilities]


time = np.arange(0, duration + interval, interval)



def plot_driving_style_estimations(duration, interval, conservative_tendency, initial_estimation):

    def generate_driving_style_estimations(duration, interval, conservative_tendency, initial_estimation):
        num_points = int(duration / interval)
        probabilities = []
        current_prob = initial_estimation

        for t in range(num_points):
            aggressive_prob = current_prob[0] * (1 - conservative_tendency)
            general_prob = current_prob[1] * (1 - conservative_tendency)
            conservative_prob = current_prob[2] + conservative_tendency * (1 - current_prob[2])


            random_adjustment = np.random.uniform(-0.02, 0.02, size=3)
            adjusted_prob = [aggressive_prob, general_prob, conservative_prob] + random_adjustment


            total_prob = sum(adjusted_prob)
            adjusted_prob = [p / total_prob for p in adjusted_prob]

            probabilities.append(adjusted_prob)
            current_prob = adjusted_prob  # 使用带有随机调整和归一化的概率作为下一个时间点的初始概率

        probabilities = np.concatenate(([initial_estimation], probabilities))  # 将初始估计与结果合并

        return probabilities

    driving_style_probabilities = generate_driving_style_estimations(duration, interval, conservative_tendency,
                                                                     initial_estimation)


    aggressive_probabilities = [p[0] for p in driving_style_probabilities]
    general_probabilities = [p[1] for p in driving_style_probabilities]
    conservative_probabilities = [p[2] for p in driving_style_probabilities]


    time = np.arange(0, duration + interval, interval)


    font_path = 'times.ttf'
    prop = font_manager.FontProperties(fname=font_path)


    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')


    ax.plot(time, aggressive_probabilities, zs=1, zdir='y', label='Aggressive')
    ax.plot(time, general_probabilities, zs=2, zdir='y', label='General')
    ax.plot(time, conservative_probabilities, zs=3, zdir='y', label='Conservative')


    ax.set_xlabel('Time (seconds)', fontproperties=prop)
    ax.set_ylabel('Driving Style', fontproperties=prop)
    ax.set_zlabel('Probability', fontproperties=prop)
    ax.set_title('Driving Style Estimations', fontproperties=prop)


    ax.legend(prop=prop)


    ax.tick_params(axis='x', labelsize=8, labelrotation=45)
    ax.tick_params(axis='y', labelsize=8)
    ax.tick_params(axis='z', labelsize=8)

    ax.xaxis.set_pane_color((0.95, 0.95, 0.95, 1))
    ax.yaxis.set_pane_color((0.95, 0.95, 0.95, 1))
    ax.zaxis.set_pane_color((0.95, 0.95, 0.95, 1))
    ax.xaxis.set_tick_params(pad=2)
    ax.yaxis.set_tick_params(pad=2)
    ax.zaxis.set_tick_params(pad=2)
    ax.xaxis.set_tick_params(width=0.5)
    ax.yaxis.set_tick_params(width=0.5)
    ax.zaxis.set_tick_params(width=0.5)


    ax.spines['bottom'].set_color((0.5, 0.5, 0.5, 0.5))
    ax.spines['top'].set_color((0.5, 0.5, 0.5, 0.5))
    ax.spines['left'].set_color((0.5, 0.5, 0.5, 0.5))
    ax.spines['right'].set_color((0.5, 0.5, 0.5, 0.5))

    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)

    ax.view_init(elev=20, azim=-40)

    plt.show()


plot_driving_style_estimations(duration, interval, conservative_tendency, initial_estimation)