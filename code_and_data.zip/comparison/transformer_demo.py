import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler

# 定义数据集类
class LaneChangeDataset(Dataset):
    def __init__(self, data, sequence_length):

        self.sequence_length = sequence_length
        self.inputs = data[:, :-1]
        self.labels = data[:, -1]


        self.inputs_sequences = []
        self.labels_sequences = []

        for i in range(len(self.inputs) - self.sequence_length):
            self.inputs_sequences.append(self.inputs[i:i + self.sequence_length])
            self.labels_sequences.append(self.labels[i + self.sequence_length - 1])

    def __len__(self):
        return len(self.inputs_sequences)

    def __getitem__(self, idx):
        return torch.tensor(self.inputs_sequences[idx], dtype=torch.float32), torch.tensor(self.labels_sequences[idx], dtype=torch.float32)


def load_and_preprocess_data(csv_file):

    df = pd.read_csv(csv_file)

    features = ['position_x', 'position_y', 'speed_v', 'heading', 'dist_to_object', 'rel_dist_to_fv', 'rel_speed', 'rel_acc', 'lane_change_decision']
    data = df[features].values

    # min-max归一化

    scaler = MinMaxScaler()
    data[:, :-1] = scaler.fit_transform(data[:, :-1])  # 对输入特征进行归一化，排除换道决策列

    return data

def validate_model(model, data, threshold=0.5):
    model.eval()
    time_diffs = []
    with torch.no_grad():
        for i, (inputs, true_decision) in enumerate(data):
            inputs = inputs.unsqueeze(0).unsqueeze(0)  # 添加batch和时间步维度
            outputs = model(inputs)
            predicted_decision = (outputs > threshold).float()
            if predicted_decision.item() == 1 and true_decision == 1:  # 换道发生
                #
                t1 = i
                t2 = i
                time_diff = abs(t1 - t2)
                time_diffs.append(time_diff)
    print(f"平均时间偏差: {np.mean(time_diffs)} 秒")
    # accuracy
    # print(f"Validation complete! Accuracy: {accuracy:.2f}%")
    print(f"平均时间偏差: {np.mean(time_diffs):.2f} 秒")
    return time_diffs

# 定义Transformer网络
class TransformerLaneChangeModel(nn.Module):
    def __init__(self, input_size, d_model, num_heads, hidden_dim, num_layers):
        super(TransformerLaneChangeModel, self).__init__()
        self.fc_in = nn.Linear(input_size, d_model)
        self.transformer_layer = nn.TransformerEncoderLayer(d_model=d_model, nhead=num_heads, dim_feedforward=hidden_dim)
        self.transformer = nn.TransformerEncoder(self.transformer_layer, num_layers=num_layers)
        self.fc_out = nn.Linear(d_model, 1)

    def forward(self, x):
        x = self.fc_in(x)
        x = self.transformer(x.unsqueeze(0))
        x = self.fc_out(x[:, -1, :])
        return torch.sigmoid(x)


csv_file = 'lc_data_record_1.csv'
sequence_length = 10

data = load_and_preprocess_data(csv_file)


dataset = LaneChangeDataset(data, sequence_length=sequence_length)
dataloader = DataLoader(dataset, batch_size=32, shuffle=True)

input_size = data.shape[1] - 1
d_model = 512
num_heads = 8
hidden_dim = 2048
num_layers = 6


model = TransformerLaneChangeModel(input_size, d_model, num_heads, hidden_dim, num_layers)
criterion = nn.BCELoss()  # 二元交叉熵
optimizer = optim.Adam(model.parameters(), lr=0.001)

def train_model(model, dataloader, criterion, optimizer, num_epochs=10):
    model.train()
    for epoch in range(num_epochs):
        running_loss = 0.0
        for inputs, labels in dataloader:
            inputs = inputs.unsqueeze(0)  # 添加batch维度
            optimizer.zero_grad()
            outputs = model(inputs)
            loss = criterion(outputs, labels.unsqueeze(1))
            loss.backward()
            optimizer.step()
            running_loss += loss.item()
        print(f"Epoch [{epoch+1}/{num_epochs}], Loss: {running_loss/len(dataloader)}")

# begin
train_model(model, dataloader, criterion, optimizer, num_epochs=10)

# save
torch.save(model.state_dict(), 'transformer_lc.pth')

# load
model.load_state_dict(torch.load('transformer_lc.pth'))


time_diffs = validate_model(model, dataset)