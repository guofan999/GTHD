from pgmpy.models import BayesianNetwork
from pgmpy.factors.discrete import TabularCPD
from pgmpy.inference import VariableElimination


t=3
DBN= [BayesianNetwork() for _ in range(t+1)]

cpd = {}
for k in ['A','B','C','D']:
    cpd.update({k:[]})


for i in range(0,t):

    cpd['A'].append(TabularCPD(variable='A' + str(i), variable_card=2, values=[[0.5], [0.5]]))   #先验时序节点定义

    if i == 0:
        cpd['B'].append(TabularCPD(variable='B' + str(i), variable_card=2, values=[[0.5, 0.5], [0.5, 0.5]],
                                   evidence=['A' + str(i)], evidence_card=[2]))


        cpd['C'].append(TabularCPD(variable='C' + str(i), variable_card=2, values=[[0.5, 0.5], [0.5, 0.5]],
                                   evidence=['A' + str(i)], evidence_card=[2]))


        cpd['D'].append(TabularCPD(variable='D' + str(i), variable_card=2, values=[[1., 0.], [0., 1.]],
                                   evidence=['C' + str(i)], evidence_card=[2]))

        DBN[i] = BayesianNetwork([('A'+str(i), 'B'+str(i)), ('A'+str(i), 'C'+str(i)), ('C'+str(i), 'D'+str(i))])


        for k in ['A', 'B', 'C', 'D']:
            DBN[i].add_cpds((cpd[k][i]))

        print(DBN[i].check_model())

        infer = VariableElimination(DBN[i])

        for k in ['B']:
            temp= infer.query(variables=[k+str(i)])
            print(k+str(i),[[temp.values[0]], [temp.values[1]]])
            cpd[k][i] = TabularCPD(variable=k+str(i), variable_card=2,
                                   values=[[temp.values[0]], [temp.values[1]]])


    if i >0:
        cpd['B'].append(TabularCPD(variable='B' + str(i), variable_card=2, values=[[0.625, 0.3,0.6,0.1], [0.375,0.7,0.4,0.9]],
                                   evidence=['A' + str(i),'B' + str(i-1)], evidence_card=[2,2]))
        print(cpd['B'][1])

        cpd['C'].append(TabularCPD(variable='C' + str(i), variable_card=2, values=[[0.5, 0.5], [0.5, 0.5]],
                                   evidence=['A' + str(i)], evidence_card=[2]))

        cpd['D'].append(TabularCPD(variable='D' + str(i), variable_card=2, values=[[1,1,1,0], [0,0,0,1]],
                                   evidence=['C' + str(i),'B' + str(i-1)], evidence_card=[2,2]))

        DBN[i] = BayesianNetwork(
            [('A' + str(i), 'B' + str(i)), ('A' + str(i), 'C' + str(i)), ('C' + str(i), 'D' + str(i)),('B' + str(i-1), 'B' + str(i)),('B' + str(i-1), 'D' + str(i))])


        for k in ['A', 'B', 'C', 'D']:
            DBN[i].add_cpds((cpd[k][i]))
        for k in ['B']:
            DBN[i].add_cpds((cpd[k][i-1]))
        print(DBN[i].check_model())

        infer = VariableElimination(DBN[i])
        for k in ['B']:
            temp = infer.query(variables=[k + str(i)])
            print(k+str(i)+'的先验概率',[[temp.values[0]], [temp.values[1]]])
            cpd[k][i] = TabularCPD(variable=k+str(i), variable_card=2,
                                   values=[[temp.values[0]], [temp.values[1]]])

infer = VariableElimination(DBN[2])
temp = infer.query(variables=['D2'])
print(temp)
