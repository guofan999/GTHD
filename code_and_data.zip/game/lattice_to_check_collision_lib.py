import math
import os
from math import sqrt
from scipy import stats
import matplotlib.pyplot as plt

# 地图文件
mapfile = 'wentinghu_one_1.map'


class Road:
    def __init__(self):
        self.id = -1
        self.lane = []
        pass


# lane id, attr and pos info
class Lane:
    def __init__(self):
        self.id = -1
        self.left = -1
        self.right = -1
        self.spd = -1
        self.width = -1
        self.points = []
        pass


# lat, lon and head
class Pos:
    def __init__(self, lat, lon, head):
        self.lat = lat
        self.lon = lon
        self.head = head
        pass


# UTM coordinates of point
class Point:
    def __init__(self, x, y, head):
        self.x = x
        self.y = y
        self.head = head


# 输入：地图文件
# 输出：地图所有的点列表
def readMap(mapfile):
    Map = []
    with open(mapfile) as m:
        rows = m.readlines()
        for i in range(1, len(rows)):
            road = Road()
            lane = Lane()
            col = rows[i].split('\t')
            road.id = int(col[0])
            lane.id = int(col[1])
            lane.left = int(col[2])
            lane.right = int(col[3])
            lane.spd = int(col[4])
            for pos in col[5:]:
                seg = pos.split(',')
                if len(seg) > 2:
                    lane.points.append(Point(float(seg[3]), float(seg[4]), float(seg[2])))
            road.lane.append(lane)
            Map.append(road)
    return Map


# 输入：全局坐标点（x,y,heading）类的列表
# 输出：全局坐标点（x,y,heading）列表索引 对应的 s-l坐标系下的 s的值的列表
def FromGlobalPointsList_to_index2s(global_point_list):
    index2s = []
    s_cur = 0
    index2s.append(s_cur)
    if len(global_point_list) != 0:
        for i in range(len(global_point_list) - 1):
            s_cur += math.sqrt((global_point_list[i + 1].x - global_point_list[i].x) ** 2 + \
                               (global_point_list[i + 1].y - global_point_list[i].y) ** 2)
            index2s.append(s_cur)
    else:
        pass
    return index2s


# 输入：规划的s列表，全局坐标点（x,y,heading）列表索引 对应的 s-l坐标系下的 s的值的列表，自车当前在全局坐标的匹配点的索引
# 输出：规划的路径点，在全局坐标下对应的 匹配点索引编号 列表。
def CalcMatchPoint(s_list, index2s, mark_cur):
    mark_max = 150 + mark_cur
    match_point_index = []
    for i in range(len(s_list)):
        mark_search = mark_cur
        while index2s[mark_search] < s_list[i]:
            mark_search += 1
            if mark_search >= mark_max:
                mark_search = mark_max
                break
        match_point_index.append(mark_search)

    return match_point_index


# 输入：规划的l列表，规划的路径点，在全局坐标下对应的 匹配点坐标点列表
# 输出：规划路径点在笛卡尔坐标系下的x，y列表
def Frenet2Cartesian(l_list, match_point_list):
    x_set = []
    y_set = []
    for i in range(len(l_list)):
        theta = match_point_list[i].head
        theta = theta - 90
        if theta < -180:
            theta = theta + 360
        if theta > 180:
            theta = theta - 360
        theta = - theta * math.pi / 180
        # print("theta",theta)
        # print("x",match_point_list[i].x,l_list[i] * math.sin(theta))
        # print("y",match_point_list[i].y,l_list[i] * math.cos(theta))
        x_set.append(match_point_list[i].x - l_list[i] * math.sin(theta))
        y_set.append(match_point_list[i].y + l_list[i] * math.cos(theta))
    return x_set, y_set


# 二分匹配点法  时间复杂度O(log(n))
# input  一系列路径点的（x,y,heading,kappa）以及障碍物点 x,y
# output match_point_x,match_point_y,nearest_distance_lateral  给出 障碍物距离我轨迹的最近距离以及匹配点的坐标
def to_find_nearest_point(x_list, y_list, heading_list, obs_x, obs_y):
    left_index = 0
    right_index = len(x_list) - 1
    while abs(right_index - left_index) > 1:
        left_distance = math.sqrt((x_list[left_index] - obs_x) ** 2 + (y_list[left_index] - obs_y) ** 2)
        right_diatance = math.sqrt((x_list[right_index] - obs_x) ** 2 + (y_list[right_index] - obs_y) ** 2)
        if right_diatance <= left_distance:
            left_index = int((left_index + right_index) / 2)
        else:
            right_index = int((left_index + right_index) / 2)
    left_distance = math.sqrt((x_list[left_index] - obs_x) ** 2 + (y_list[left_index] - obs_y) ** 2)
    right_diatance = math.sqrt((x_list[right_index] - obs_x) ** 2 + (y_list[right_index] - obs_y) ** 2)
    nearest_dis = (left_distance + right_diatance) / 2
    if left_distance <= right_diatance:
        match_index = left_index
    else:
        match_index = right_index
    match_point_x = x_list[match_index]
    match_point_y = y_list[match_index]
    match_point_heading = heading_list[match_index]
    if match_index == 0:
        vector_1 = [(obs_x - x_list[match_index]), (obs_y - y_list[match_index])]
        vector_2 = [(obs_x - x_list[match_index + 1]), (obs_y - y_list[match_index + 1])]
        nearest_distance_lateral = (vector_1[0] * vector_2[1] - vector_1[1] * vector_2[0]) / \
                                   (math.sqrt((x_list[match_index] - x_list[match_index + 1]) ** 2 + (
                                           y_list[match_index] - y_list[match_index + 1]) ** 2))
    elif match_index == (len(x_list) - 1):
        vector_1 = [(obs_x - x_list[match_index]), (obs_y - y_list[match_index])]
        vector_2 = [(obs_x - x_list[match_index - 1]), (obs_y - y_list[match_index - 1])]
        nearest_distance_lateral = (vector_1[0] * vector_2[1] - vector_1[1] * vector_2[0]) / \
                                   (math.sqrt((x_list[match_index] - x_list[match_index - 1]) ** 2 + (
                                           y_list[match_index] - y_list[match_index - 1]) ** 2))
    else:
        dis_match_point_left = math.sqrt(
            (x_list[match_index + 1] - obs_x) ** 2 + (y_list[match_index + 1] - obs_y) ** 2)
        dis_match_point_right = math.sqrt(
            (x_list[match_index + 1] - obs_x) ** 2 + (y_list[match_index + 1] - obs_y) ** 2)
        if dis_match_point_left <= dis_match_point_right:
            vector_1 = [(obs_x - x_list[match_index]), (obs_y - y_list[match_index])]
            vector_2 = [(obs_x - x_list[match_index - 1]), (obs_y - y_list[match_index - 1])]
            nearest_distance_lateral = (vector_1[0] * vector_2[1] - vector_1[1] * vector_2[0]) / \
                                       (math.sqrt((x_list[match_index] - x_list[match_index - 1]) ** 2 + (
                                               y_list[match_index] - y_list[match_index - 1]) ** 2))
        else:
            vector_1 = [(obs_x - x_list[match_index]), (obs_y - y_list[match_index])]
            vector_2 = [(obs_x - x_list[match_index + 1]), (obs_y - y_list[match_index + 1])]
            nearest_distance_lateral = (vector_1[0] * vector_2[1] - vector_1[1] * vector_2[0]) / \
                                       (math.sqrt((x_list[match_index] - x_list[match_index + 1]) ** 2 + (
                                               y_list[match_index] - y_list[match_index + 1]) ** 2))
    return match_point_x, match_point_y, match_point_heading, nearest_distance_lateral, nearest_dis, match_index


# 根据 定位点的x，y，heading 自车的长宽度  确定 车顶点的坐标
# 能给出顶点坐标， 但是方位是不准的。
# input   x，y，heading，length,width
# output  rectangle_points_list
def to_get_ego_vertexs(x, y, heading, length, width):
    rectangle_points_list = []
    l = math.sqrt((length / 2) ** 2 + (width / 2) ** 2)
    if heading >= 0:
        theta_left_front = heading + math.atan((0.5 * width) / (0.5 * length))
        theta_left_behind = heading + math.pi - math.atan((0.5 * width) / (0.5 * length))
        theta_right_front = heading - math.atan((0.5 * width) / (0.5 * length))
        theta_right_behind = heading - math.pi + math.atan((0.5 * width) / (0.5 * length))
    else:
        theta_left_front = heading + math.atan((0.5 * width) / (0.5 * length))
        theta_left_behind = heading - math.pi + math.atan((0.5 * width) / (0.5 * length))
        theta_right_front = heading - math.atan((0.5 * width) / (0.5 * length))
        theta_right_behind = heading + math.pi - math.atan((0.5 * width) / (0.5 * length))
    point_left_front_x = x + l * math.cos(theta_left_front)
    point_left_front_y = y + l * math.sin(theta_left_front)
    point_left_behind_x = x + l * math.cos(theta_left_behind)
    point_left_behind_y = y + l * math.sin(theta_left_behind)
    point_right_front_x = x + l * math.cos(theta_right_front)
    point_right_front_y = y + l * math.sin(theta_right_front)
    point_right_behind_x = x + l * math.cos(theta_right_behind)
    point_right_behind_y = y + l * math.sin(theta_right_behind)
    rectangle_points_list = [[point_left_front_x, point_left_front_y], [point_right_front_x, point_right_front_y], \
                             [point_left_behind_x, point_left_behind_y], [point_right_behind_x, point_right_behind_y]]
    return rectangle_points_list


# 分离轴定理来得到，圆与矩形 是否重叠
# input ego_rectangle_points，obs_round_points
# output separation_alex_result(0.5/1,  0.5表示无重叠,但可能发生碰撞，1表示有重叠，一定会发生碰撞)
def to_get_separation_alex_reslut_for_round(ego_rectangle_points, obs_round_points, dis_obs):
    def normalize(vector):
        """
        :return: The vector scaled to a length of 1
        """
        norm = sqrt(vector[0] ** 2 + vector[1] ** 2)
        return vector[0] / norm, vector[1] / norm

    def dot(vector1, vector2):
        """
        :return: The dot (or scalar) product of the two vectors
        """
        return vector1[0] * vector2[0] + vector1[1] * vector2[1]

    def edge_direction(point0, point1):
        """
        :return: A vector going from point0 to point1
        """
        return point1[0] - point0[0], point1[1] - point0[1]

    def orthogonal(vector):
        """
        :return: A new vector which is orthogonal to the given vector
        """
        return vector[1], -vector[0]

    def vertices_to_edges(vertices):
        """
        :return: A list of the edges of the vertices as vectors
        """
        return [edge_direction(vertices[i], vertices[(i + 1) % len(vertices)])
                for i in range(len(vertices))]

    def project(vertices, axis):
        """
        :return: A vector showing how much of the vertices lies along the axis
        """
        dots = [dot(vertex, axis) for vertex in vertices]
        return [min(dots), max(dots)]

    def overlap(projection1, projection2):
        """
        :return: Boolean indicating if the two projections overlap
        """
        return min(projection1) <= max(projection2) and \
               min(projection2) <= max(projection1)

    def separating_axis_theorem(vertices_a, vertices_b):
        edges = vertices_to_edges(vertices_a) + vertices_to_edges(vertices_b)
        # get all edges
        axes = [normalize(orthogonal(edge)) for edge in edges]
        for axis in axes:
            projection_a = project(vertices_a, axis)
            projection_b = project(vertices_b, axis)
            overlapping = overlap(projection_a, projection_b)

            if not overlapping:
                return False

        return True

    def get_collision_p_round(x):
        mean = 3
        std = 0.5
        z = (x - mean) / std
        p = 1 - stats.norm.cdf(z)
        return p

    def get_collision_p_rectangle(x):
        mean = 2.8
        std = 0.5
        z = (x - mean) / std
        p = 1 - stats.norm.cdf(z)
        return p

    result = separating_axis_theorem(ego_rectangle_points, obs_round_points)
    # print("result",result)
    if result is False:
        # print("未发生重合")
        if len(obs_round_points) == 2:
            separation_alex_result = get_collision_p_round(dis_obs)
        else:
            separation_alex_result = get_collision_p_rectangle(dis_obs)
    else:
        separation_alex_result = 1

    return separation_alex_result


# 找到圆心距离四个顶点最近的点，再在这两个点之间 找距离为圆半径的另一个点
# input ego_rectangle_points、covered_obs_round
# output  obs_round_points
def to_get_obs_round_points(ego_rectangle_points, covered_obs_round):
    min_dis_index = 0
    min_dis = 10000
    for i in range(len(ego_rectangle_points)):
        dis_to_round = math.sqrt((ego_rectangle_points[i][0] - covered_obs_round[0]) ** 2 + (
                ego_rectangle_points[i][1] - covered_obs_round[1]) ** 2)
        if (dis_to_round < min_dis):
            min_dis = dis_to_round
            min_dis_index = i

    try:
        theta = math.atan2(((ego_rectangle_points[min_dis_index][1] - covered_obs_round[1])),
                           (ego_rectangle_points[min_dis_index][0] - covered_obs_round[0]))
        another_point_x = covered_obs_round[0] + covered_obs_round[2] * math.cos(theta)
        another_point_y = covered_obs_round[1] + covered_obs_round[2] * math.sin(theta)
    except:
        another_point_x = covered_obs_round[0]
        if (covered_obs_round[1] > ego_rectangle_points[min_dis_index][1]):
            another_point_y = covered_obs_round[1] - covered_obs_round[2]
        else:
            another_point_y = covered_obs_round[1] + covered_obs_round[2]

    ego_rectangle_points_center_x = ((ego_rectangle_points[0][0] + ego_rectangle_points[1][0]) / 2 + \
                                     (ego_rectangle_points[2][0] + ego_rectangle_points[3][0]) / 2) / 2
    ego_rectangle_points_center_y = (ego_rectangle_points[0][1] + ego_rectangle_points[1][1] + \
                                     ego_rectangle_points[2][1] + ego_rectangle_points[3][1]) / 4

    try:
        theta = math.atan2(((ego_rectangle_points_center_y - covered_obs_round[1])),
                           (ego_rectangle_points_center_x - covered_obs_round[0]))
        nother_point_x = covered_obs_round[0] + covered_obs_round[2] * math.cos(theta)
        nother_point_y = covered_obs_round[1] + covered_obs_round[2] * math.sin(theta)
    except:
        nother_point_x = covered_obs_round[0]
        if (covered_obs_round[1] > ego_rectangle_points_center_y):
            nother_point_y = covered_obs_round[1] - covered_obs_round[2]
        else:
            nother_point_y = covered_obs_round[1] + covered_obs_round[2]

    return [[covered_obs_round[0], covered_obs_round[1]], [another_point_x, another_point_y],
            [nother_point_x, nother_point_y]]


# 总方法：调用其他的函数
# input  未来的轨迹路径点序列 x_list,y_list, heading_list,自车尺寸信息 ego_length，ego_width， covered_obs_round_list，covered_obs_rectangle_list(这两者可能为空)
def to_get_check_collision_result(x_list, y_list, heading_list, ego_length, ego_width, covered_obs_round_list,
                                  covered_obs_rectangle_list):
    if ((not covered_obs_round_list) and (not covered_obs_rectangle_list)):
        check_collosion_result = 0
    else:
        result_round_list = []
        result_rectangle_list = []
        for i in range(len(covered_obs_round_list)):
            temp = to_find_nearest_point(x_list, y_list, heading_list, covered_obs_round_list[i][0],
                                         covered_obs_round_list[i][1])
            match_point_heading = temp[2]
            center_x = temp[0]
            center_y = temp[1]
            # print("center_x",center_x,center_y,match_point_heading,temp[3],temp[4])
            width = ego_width
            Length = ego_length
            temp_points = to_get_ego_vertexs(center_x, center_y, match_point_heading, Length, width)
            match_point_heading = match_point_heading * 180 / math.pi
            # plt.gca().add_patch(plt.Rectangle((temp_points[2][0], temp_points[2][1]),
            #                                   Length,width, match_point_heading, color='b'))

            distance_ego_to_obs_min = (0.25 * ((ego_width) ** 2 + (ego_length) ** 2)) ** 0.5 + \
                                      covered_obs_round_list[i][2]
            # print("distance_ego_to_obs_min",distance_ego_to_obs_min)
            if (temp[3] > distance_ego_to_obs_min or temp[4] > distance_ego_to_obs_min + 8):
                result_round_list.append(0)
            else:
                ego_rectangle_points = to_get_ego_vertexs(temp[0], temp[1], temp[2], ego_length, ego_width)
                obs_round_points = to_get_obs_round_points(ego_rectangle_points, covered_obs_round_list[i])
                # print("ego_rectangle_points",ego_rectangle_points,obs_round_points)
                separation_alex_result = to_get_separation_alex_reslut_for_round(ego_rectangle_points, obs_round_points,
                                                                                 temp[4])
                result_round_list.append(separation_alex_result)
        for i in range(len(covered_obs_rectangle_list)):
            temp = to_find_nearest_point(x_list, y_list, heading_list, covered_obs_rectangle_list[i][0],
                                         covered_obs_rectangle_list[i][1])
            match_point_heading = temp[2]
            center_x = temp[0]
            center_y = temp[1]
            # print("center_x",center_x,center_y,match_point_heading,temp[3],temp[4])
            width = ego_width
            Length = ego_length
            temp_points = to_get_ego_vertexs(center_x, center_y, match_point_heading, Length, width)
            match_point_heading = match_point_heading * 180 / math.pi
            # plt.gca().add_patch(plt.Rectangle((temp_points[2][0], temp_points[2][1]), Length,
            #                                   width, match_point_heading, color='b'))

            distance_ego_to_obs_min = (0.25 * (ego_length + covered_obs_rectangle_list[i][2][0]) ** 2 + \
                                       0.25 * (ego_width + covered_obs_rectangle_list[i][2][1]) ** 2) ** 0.5
            # print("distance_ego_to_obs_min",distance_ego_to_obs_min)
            if (temp[3] > distance_ego_to_obs_min or temp[4] > distance_ego_to_obs_min + 8):
                result_rectangle_list.append(0)
            else:
                ego_rectangle_points = to_get_ego_vertexs(temp[0], temp[1], temp[2], ego_length, ego_width)
                obs_rectangle_points = to_get_ego_vertexs(covered_obs_rectangle_list[i][0],
                                                          covered_obs_rectangle_list[i][1], \
                                                          temp[2], covered_obs_rectangle_list[i][2][0],
                                                          covered_obs_rectangle_list[i][2][1])
                separation_alex_result = to_get_separation_alex_reslut_for_round(ego_rectangle_points,
                                                                                 obs_rectangle_points, temp[4])
                result_rectangle_list.append(separation_alex_result)
        result_obs_all_list = result_rectangle_list + result_round_list

        print("result_obs_all_list", result_obs_all_list)

        check_collosion_result = max(result_obs_all_list)

    return check_collosion_result


# 输入：轨迹的x_list和y_list
# 输出：轨迹的heading_list和kappa_list组成的字典dict
def to_get_heading_kappa(x_plan_list, y_plan_list):
    dx_pre_list = []
    dx_after_list = []
    dx_final_list = []
    ds_final_list = []
    heading_plan_list = []
    dx_after_list.append(x_plan_list[1] - x_plan_list[0])
    for i in range(len(x_plan_list) - 1):
        dx_pre_list.append(x_plan_list[i + 1] - x_plan_list[i])
        dx_after_list.append(x_plan_list[i + 1] - x_plan_list[i])
    dx_pre_list.append(x_plan_list[-1] - x_plan_list[-2])
    dy_pre_list = []
    dy_after_list = []
    dy_final_list = []
    dy_after_list.append(y_plan_list[1] - y_plan_list[0])
    for i in range(len(y_plan_list) - 1):
        dy_pre_list.append(y_plan_list[i + 1] - y_plan_list[i])
        dy_after_list.append(y_plan_list[i + 1] - y_plan_list[i])
    dy_pre_list.append(y_plan_list[-1] - y_plan_list[-2])
    for i in range(len(x_plan_list)):
        dx_final_list.append((dx_after_list[i] + dx_pre_list[i]) / 2)
        dy_final_list.append((dy_after_list[i] + dy_pre_list[i]) / 2)
        heading_plan_list.append(math.atan2(dy_final_list[-1], dx_final_list[-1]))
        temp_ds_i = math.sqrt(dx_final_list[-1] ** 2 + dy_final_list[-1] ** 2)
        ds_final_list.append(temp_ds_i)
    # dx_final_list/d_y_final_list/ds_final_list   差分后的dx列表/dy列表/ds列表/heading_plan列表

    dheading_pre_list = []
    dheading_after_list = []
    dheading_final_list = []

    kappa_plan_list = []

    dheading_after_list.append(heading_plan_list[1] - heading_plan_list[0])
    for i in range(len(heading_plan_list) - 1):
        dheading_pre_list.append(heading_plan_list[i + 1] - heading_plan_list[i])
        dheading_after_list.append(heading_plan_list[i + 1] - heading_plan_list[i])
    dheading_pre_list.append(heading_plan_list[-1] - heading_plan_list[-2])
    for i in range(len(dheading_after_list)):
        dheading_final_list.append((dheading_after_list[i] + dheading_pre_list[i]) / 2)
        kappa_plan_list.append(math.sin(dheading_final_list[-1]) / ds_final_list[i])

    dict = {"heading_plan_list": heading_plan_list, "kappa_plan_list": kappa_plan_list}
    return dict


# 输入：读地图输出的字典信息，碰撞检测模块输出的需要的画图的字典信息
# 输出：绘制图像
def lattice_collision_check_plot(Map_dict, dict_plot):
    ego_width = 2.1
    ego_length = 5

    match_point_index = dict_plot["match_point_index"]
    x_plan_list = dict_plot["x_plan_list"]
    y_plan_list = dict_plot["y_plan_list"]
    heading_plan_list = dict_plot["heading_plan_list"]
    covered_obs_round_list = dict_plot["covered_obs_round_list"]
    covered_obs_rectangle_list = dict_plot["covered_obs_rectangle_list"]
    x_list = Map_dict["X_list"]
    y_list = Map_dict["Y_list"]
    heading_list = Map_dict["heading_list"]
    plt.plot(x_list[match_point_index[0]:match_point_index[-1]],
             y_list[match_point_index[0]:match_point_index[-1]], color='k', marker='.', linestyle='dashed')

    plt.plot(x_plan_list, y_plan_list, color='r', marker='.', linestyle='dashed')

    for i in range(len(covered_obs_round_list)):
        plt.gca().add_patch(plt.Circle((covered_obs_round_list[i][0], covered_obs_round_list[i][1]),
                                       covered_obs_round_list[i][2], color="blue", fill=True))

    for i in range(len(covered_obs_rectangle_list)):
        match_obs_heading = to_find_nearest_point(x_list, y_list, heading_list,
                                                  covered_obs_rectangle_list[i][0], covered_obs_rectangle_list[i][1])[2]
        center_x = covered_obs_rectangle_list[i][0]
        center_y = covered_obs_rectangle_list[i][1]
        width = covered_obs_rectangle_list[i][2][1]
        Length = covered_obs_rectangle_list[i][2][0]
        temp = to_get_ego_vertexs(center_x, center_y, match_obs_heading, Length, width)
        match_obs_heading = match_obs_heading * 180 / math.pi
        plt.gca().add_patch(plt.Rectangle((temp[2][0], temp[2][1]), Length,
                                          width, match_obs_heading, color='k'))

    for i in range(len(covered_obs_round_list)):
        temp = to_find_nearest_point(x_plan_list, y_plan_list, heading_plan_list, covered_obs_round_list[i][0],
                                     covered_obs_round_list[i][1])
        match_point_heading = temp[2]
        center_x = temp[0]
        center_y = temp[1]
        width = ego_width
        Length = ego_length
        temp_points = to_get_ego_vertexs(center_x, center_y, match_point_heading, Length, width)
        match_point_heading = match_point_heading * 180 / math.pi
        plt.gca().add_patch(plt.Rectangle((temp_points[2][0], temp_points[2][1]),
                                          Length, width, match_point_heading, color='r'))
    for i in range(len(covered_obs_rectangle_list)):
        temp = to_find_nearest_point(x_plan_list, y_plan_list, heading_plan_list, covered_obs_rectangle_list[i][0],
                                     covered_obs_rectangle_list[i][1])
        match_point_heading = temp[2]
        center_x = temp[0]
        center_y = temp[1]
        # print("center_x", center_x, center_y, match_point_heading, temp[3], temp[4])
        width = ego_width
        Length = ego_length
        temp_points = to_get_ego_vertexs(center_x, center_y, match_point_heading, Length, width)
        match_point_heading = match_point_heading * 180 / math.pi
        plt.gca().add_patch(plt.Rectangle((temp_points[2][0], temp_points[2][1]), Length,
                                          width, match_point_heading, color='r'))
    plt.show()


# 被调用的核心函数，碰撞检测的接口。
# 输入：规划的s列表，l列表，从ROI function 里面的障碍物列表，本车定位点，读地图输出的字典信息
# 输出：dict_plan,dict_plot 规划数据字典和画图数据字典
def lattice_collision_check(s_list, l_list, obj_list, ego_Point_class, Map_dict):
    ego_width = 2.1
    ego_length = 5
    min_ego_turn_radius = 4.5

    mark_cur = to_find_nearest_point(Map_dict["X_list"], Map_dict["Y_list"], Map_dict["heading_list"],
                                     ego_Point_class.x, ego_Point_class.y)[5]
    index2s = FromGlobalPointsList_to_index2s(Map_dict["global_point_list"])  # 每个全局路径点对应的s
    match_point_index = CalcMatchPoint(s_list, index2s, mark_cur)  # TODO match_point_index 是一个列表
    match_point_list = []
    for i in range(len(match_point_index)):
        match_point_list.append(Map_dict["global_point_list"][match_point_index[i]])
    x_plan_list, y_plan_list = Frenet2Cartesian(l_list, match_point_list)
    heading_plan_list = to_get_heading_kappa(x_plan_list, y_plan_list)["heading_plan_list"]
    kappa_plan_list = to_get_heading_kappa(x_plan_list, y_plan_list)["kappa_plan_list"]
    covered_obs_round_list = []
    covered_obs_rectangle_list = []
    for i in range(len(obj_list)):
        if obj_list[i]["type"] == "person" or obj_list[i]["type"] == "chil":
            # min_obs_round_radius = math.sqrt((obj_list[i]["Length"] / 2) ** 2 + (obj_list[i]["Width"] / 2) ** 2)
            min_obs_round_radius = 0.8
            covered_obs_radius = min_obs_round_radius + min_ego_turn_radius * 0.05
            covered_obs_x = obj_list[i]["x"]
            covered_obs_y = obj_list[i]["y"]
            covered_obs_round_list.append([covered_obs_x, covered_obs_y, covered_obs_radius])
        elif (obj_list[i]["type"] == "bus" or obj_list[i]["type"] == "car" or obj_list[i]["type"] == "truck" or
              obj_list[i]["type"] == "bicycle"):
            covered_obs_length = obj_list[i]["Length"] + min_ego_turn_radius * 0.1
            covered_obs_width = obj_list[i]["Width"] + min_ego_turn_radius * 0.1
            covered_obs_x = obj_list[i]["x"]
            covered_obs_y = obj_list[i]["y"]
            covered_obs_rectangle_list.append([covered_obs_x, covered_obs_y, (covered_obs_length, covered_obs_width)])
    result_check = to_get_check_collision_result(x_plan_list, y_plan_list, heading_plan_list, ego_length, ego_width,
                                                 covered_obs_round_list, covered_obs_rectangle_list)  # float [0,1]
    dict_plan = {"s_list": s_list, "l_list": l_list, "x_plan_list": x_plan_list, "y_plan_list": y_plan_list,
                 "heading_plan_list": heading_plan_list, "kappa_plan_list": kappa_plan_list,
                 "result_check": result_check}
    dict_plot = {"match_point_index": match_point_index, "x_plan_list": x_plan_list, "y_plan_list": y_plan_list,
                 "covered_obs_round_list": covered_obs_round_list, "heading_plan_list": heading_plan_list,
                 "covered_obs_rectangle_list": covered_obs_rectangle_list}
    return dict_plan, dict_plot


# 测试frenet坐标系转换成笛卡尔坐标系模块以及碰撞检测功能模块
# 读取一个实际的地图，得到真实的mark下标。
def main():
    mapfile = 'wentinghu_one_1.map'
    assert os.path.isfile(mapfile), 'map file is not exist, please check again'
    Map = readMap(mapfile)
    x_list = []
    y_list = []
    heading_list = []
    global_point_list = []
    for j in range(len(Map)):
        for i in range(len(Map[j].lane[0].points)):
            global_point_list.append(Map[j].lane[0].points[i])
            x_list.append(Map[j].lane[0].points[i].x)
            y_list.append(Map[j].lane[0].points[i].y)
            theta = (Map[j].lane[0].points[i].head)
            theta = theta - 90
            if (theta < -180):
                theta = theta + 360
            if (theta > 180):
                theta = theta - 360
            theta = - theta * math.pi / 180
            heading_list.append(theta)
    Map_dict = {"global_point_list": global_point_list,
                "X_list": x_list,
                "Y_list": y_list,
                "heading_list": heading_list}
    cur_point = Point(397305.511143, 3869705.01242, 228.35)  # first point
    mark_cur = to_find_nearest_point(x_list, y_list, heading_list, cur_point.x, cur_point.y)[5]
    # # print("mark_cur",mark_cur)
    #
    index2s = FromGlobalPointsList_to_index2s(global_point_list)  # 每个全局路径点对应的s
    s_list = [1 + index2s[mark_cur], 3 + index2s[mark_cur], 6 + index2s[mark_cur],
              9 + index2s[mark_cur], 30 + index2s[mark_cur], 40 + index2s[mark_cur]]
    l_list = [1, 2.5, 3.5, 3.5, 3.5, 3.5]

    obs_list_x = [x_list[50], x_list[20], x_list[10], x_list[5]]
    obs_list_y = [y_list[50], y_list[20], y_list[10], y_list[5]]
    obj_dict_list = [{"type": "person", "x": obs_list_x[0], "y": obs_list_y[0], "Length": 0.5, "Width": 0.5},
                     {"type": "car", "x": obs_list_x[3], "y": obs_list_y[3], "Length": 4.5, "Width": 2.1}]
    dict_plan, dict_plot = lattice_collision_check(s_list, l_list, obj_dict_list, cur_point, Map_dict)
    print(dict_plan["result_check"])
    lattice_collision_check_plot(Map_dict, dict_plot)

    #
    # match_point_index = CalcMatchPoint(s_list, index2s, mark_cur)
    # print("match_point_index", match_point_index)
    # plt.plot(x_list[match_point_index[0]:match_point_index[-1]],
    #          y_list[match_point_index[0]:match_point_index[-1]], color='k', marker='.', linestyle='dashed')
    # match_point_list = []
    # for i in range(len(match_point_index)):
    #     match_point_list.append(global_point_list[match_point_index[i]])
    # x_set, y_set = Frenet2Cartesian(l_list, match_point_list)
    # obs_list_x = [x_list[50], x_list[20], x_list[10], x_list[5]]
    # obs_list_y = [y_list[50], y_list[20], y_list[10], y_list[5]]
    #
    # x_plan_list = x_set
    # y_plan_list = y_set
    #
    # heading_plan_list = to_get_heading_kappa(x_plan_list,y_plan_list)["heading_plan_list"]
    #
    # plt.plot(x_plan_list, y_plan_list, color='r', marker='.', linestyle='dashed')
    #
    # ego_width = 2.1
    # ego_length = 5
    #
    # covered_obs_round_list = [[obs_list_x[0], obs_list_y[0], 0.8035533905932738]]
    # # covered_obs_round_list = [[obs_list_x[2], obs_list_y[2], 0.8035533905932738],[obs_list_x[3], obs_list_y[3], 0.8035533905932738]]
    #
    # # covered_obs_round_list = []
    # for i in range(len(covered_obs_round_list)):
    #     plt.gca().add_patch(plt.Circle((covered_obs_round_list[i][0],covered_obs_round_list[i][1]),
    #                                    covered_obs_round_list[i][2],color="blue",fill=True))
    #
    # covered_obs_rectangle_list = [[obs_list_x[0],obs_list_y[0], (4.45, 2.45)]]
    # covered_obs_rectangle_list = []
    # for i in range(len(covered_obs_rectangle_list)):
    #     match_obs_heading = to_find_nearest_point(x_list,y_list,heading_list,
    #                           covered_obs_rectangle_list[i][0],covered_obs_rectangle_list[i][1])[2]
    #     center_x = covered_obs_rectangle_list[i][0]
    #     center_y = covered_obs_rectangle_list[i][1]
    #     width = covered_obs_rectangle_list[i][2][1]
    #     Length = covered_obs_rectangle_list[i][2][0]
    #     temp = to_get_ego_vertexs(center_x,center_y,match_obs_heading,Length,width)
    #
    #     match_obs_heading = match_obs_heading * 180 / math.pi
    #     print("match_obs_heading",match_obs_heading)
    #     plt.gca().add_patch(plt.Rectangle((temp[2][0], temp[2][1]),Length,
    #                                       width, match_obs_heading,color='k'))
    #
    # # print("heading_list_debug",len(y_plan_list),heading_list)
    # result_check = to_get_check_collision_result(x_plan_list, y_plan_list, heading_plan_list, ego_length, ego_width,
    #                                              covered_obs_round_list, covered_obs_rectangle_list)
    # plt.show()
    # print(result_check)
    print("over!")


if __name__ == '__main__':
    main()
