import math
import os
import matplotlib.pyplot as plt

mapfile = 'wentinghu_one_1.map'

class Road:
    def __init__(self):
        self.id = -1
        self.lane = []
        pass
#lane id, attr and pos info
class Lane:
    def __init__(self):
        self.id = -1
        self.left = -1
        self.right = -1
        self.spd = -1
        self.width = -1
        self.points = []
        pass
#lat, lon and head
class Pos:
    def __init__(self, lat, lon, head):
        self.lat = lat
        self.lon = lon
        self.head = head
        pass
#UTM coordinates of point
class Point:
    def __init__(self, x, y, head):
        self.x = x
        self.y = y
        self.head = head

def readMap(mapfile):
    Map = []
    with open(mapfile) as m:
        rows = m.readlines()
        for i in range(1,len(rows)):
            road = Road()
            lane = Lane()
            col = rows[i].split('\t')
            road.id = int(col[0])
            lane.id = int(col[1])
            lane.left = int(col[2])
            lane.right = int(col[3])
            lane.spd = int(col[4])
            for pos in col[5:]:
                seg = pos.split(',')
                if len(seg) > 2:
                    lane.points.append(Point(float(seg[3]), float(seg[4]), float(seg[2])))
            road.lane.append(lane)
            Map.append(road)
    return Map

def Frenet2Cartesian(l_list,match_point_list):
    x_set = []
    y_set = []
    for i in range(len(l_list)):
        theta = (match_point_list[i].head)
        theta = theta - 90
        if (theta < -180):
            theta = theta + 360
        if (theta > 180):
            theta = theta - 360
        theta = - theta * math.pi / 180
        # print("theta",theta)
        # print("x",match_point_list[i].x,l_list[i] * math.sin(theta))
        # print("y",match_point_list[i].y,l_list[i] * math.cos(theta))
        x_set.append(match_point_list[i].x - l_list[i] * math.sin(theta))
        y_set.append(match_point_list[i].y + l_list[i] * math.cos(theta))
    return x_set,y_set

def CalcMatchPoint(s_list,index2s,mark_cur):
    mark_max = 150 + mark_cur
    match_point_index = []
    for i in range(len(s_list)):
        mark_search = mark_cur
        while(index2s[mark_search] < s_list[i]):
            mark_search += 1
            if(mark_search >= mark_max):
                mark_search = mark_max
                break
        match_point_index.append(mark_search)

    return match_point_index

def FromGlobalPointsList_to_index2s(global_point_list):
    index2s = []
    s_cur = 0
    index2s.append(s_cur)
    if len(global_point_list) != 0:
        for i in range(len(global_point_list)-1):
            s_cur += math.sqrt((global_point_list[i+1].x -global_point_list[i].x)**2 + \
                     (global_point_list[i+1].y -global_point_list[i].y)**2)
            index2s.append(s_cur)
    else:
        pass
    return index2s

def to_find_nearest_point(x_list,y_list,heading_list,cur_x,cur_y):
    left_index = 0
    right_index = len(x_list) - 1
    while(abs(right_index - left_index) > 1):
        left_distance = math.sqrt((x_list[left_index] - cur_x)**2 + (y_list[left_index] - cur_y)**2)
        right_diatance = math.sqrt((x_list[right_index] - cur_x)**2 + (y_list[right_index] - cur_y)**2)
        if(right_diatance <= left_distance):
            left_index = int((left_index + right_index)/2)
        else:
            right_index = int((left_index + right_index)/2)
    left_distance = math.sqrt((x_list[left_index] - cur_x) ** 2 + (y_list[left_index] - cur_y) ** 2)
    right_diatance = math.sqrt((x_list[right_index] - cur_x) ** 2 + (y_list[right_index] - cur_y) ** 2)
    if(left_distance <= right_diatance):
        match_index = left_index
    else:
        match_index = right_index
    match_point_x = x_list[match_index]
    match_point_y = y_list[match_index]
    match_point_heading = heading_list[match_index]
    if (match_index == 0):
        vector_1 = [(cur_x - x_list[match_index]),(cur_y - y_list[match_index])]
        vector_2 = [(cur_x - x_list[match_index + 1]),(cur_y - y_list[match_index + 1])]
        nearest_distance = (vector_1[0]*vector_2[1] - vector_1[1]*vector_2[0])/  \
            (math.sqrt((x_list[match_index] - x_list[match_index + 1])**2 + (y_list[match_index] -y_list[match_index + 1])**2))
    elif(match_index == (len(x_list) -1)):
        vector_1 = [(cur_x - x_list[match_index]), (cur_y - y_list[match_index])]
        vector_2 = [(cur_x - x_list[match_index - 1]), (cur_y - y_list[match_index - 1])]
        nearest_distance = (vector_1[0] * vector_2[1] - vector_1[1] * vector_2[0]) / \
                           (math.sqrt((x_list[match_index] - x_list[match_index - 1]) ** 2 + (
                                       y_list[match_index] - y_list[match_index - 1]) ** 2))
    else:
        dis_match_point_left = math.sqrt((x_list[match_index + 1] - cur_x)**2 + (y_list[match_index + 1] - cur_y)**2)
        dis_match_point_right = math.sqrt((x_list[match_index + 1] - cur_x)**2 + (y_list[match_index + 1] - cur_y)**2)
        if(dis_match_point_left <= dis_match_point_right):
            vector_1 = [(cur_x - x_list[match_index]), (cur_y - y_list[match_index])]
            vector_2 = [(cur_x - x_list[match_index - 1]), (cur_y - y_list[match_index - 1])]
            nearest_distance = (vector_1[0] * vector_2[1] - vector_1[1] * vector_2[0]) / \
                               (math.sqrt((x_list[match_index] - x_list[match_index - 1]) ** 2 + (
                                       y_list[match_index] - y_list[match_index - 1]) ** 2))
        else:
            vector_1 = [(cur_x - x_list[match_index]), (cur_y - y_list[match_index])]
            vector_2 = [(cur_x - x_list[match_index + 1]), (cur_y - y_list[match_index + 1])]
            nearest_distance = (vector_1[0] * vector_2[1] - vector_1[1] * vector_2[0]) / \
                               (math.sqrt((x_list[match_index] - x_list[match_index + 1]) ** 2 + (
                                           y_list[match_index] - y_list[match_index + 1]) ** 2))
    return match_index,match_point_x,match_point_y,match_point_heading,nearest_distance

def main():
    assert os.path.isfile(mapfile), 'map file is not exist, please check again'
    Map = readMap(mapfile)
    X_list = []
    Y_list = []
    heading_list = []
    global_point_list = []
    for j in range(len(Map)):
        for i in range(len(Map[j].lane[0].points)):
            global_point_list.append(Map[j].lane[0].points[i])
            X_list.append(Map[j].lane[0].points[i].x)
            Y_list.append(Map[j].lane[0].points[i].y)
            heading_list.append(Map[j].lane[0].points[i].head)
    plt.cla()
    plt.scatter(X_list,Y_list)
    plt.grid(True)
    print('路线绘制完成！')
    plt.show()
    cur_point = Point(397303.107202,3869703.16497,230.14)  # sub from GPS
    mark_cur = to_find_nearest_point(X_list,Y_list,heading_list,cur_point.x,cur_point.y)[0]
    print("mark_cur",mark_cur)

    index2s = FromGlobalPointsList_to_index2s(global_point_list)  # 每个全局路径点对应的s
    s_list = [1+index2s[mark_cur], 3+index2s[mark_cur], 6+index2s[mark_cur],
              9+index2s[mark_cur],30+index2s[mark_cur],40+index2s[mark_cur]]
    l_list = [1, 2, 3, 3.5,3.5,3.5]
    # print("global_point_list",global_point_list)
    print("index2s",index2s)
    # print(len(global_point_list),len(index2s))
    match_point_index = CalcMatchPoint(s_list, index2s, mark_cur)
    plt.plot(X_list[match_point_index[0]:match_point_index[-1]],
             Y_list[match_point_index[0]:match_point_index[-1]], color='k', marker='.', linestyle='dashed')
    print("match_point_index",match_point_index)
    match_point_list = []
    for i in range(len(match_point_index)):
        match_point_list.append(global_point_list[match_point_index[i]])

    x_set, y_set = Frenet2Cartesian(l_list, match_point_list)
    # print("x_set",x_set)
    # print("y_set",y_set)
    x_list = x_set
    y_list = y_set
    plt.plot(x_list, y_list, color='r', marker='.', linestyle='dashed')
    plt.show()

if __name__ == '__main__':
    main()