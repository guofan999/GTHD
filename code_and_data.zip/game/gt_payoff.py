import time
import json

import numpy
import rospy
import std_msgs.msg
import lanechange_tools as tool
from sympy import *
import numpy as np
import threading
import math
import signal
import nashpy

npc_list = []
ego_veh_dict = {}

ck = 0

is_exit = False
content = {'Stop': 0, 'LC': 0, 'lux4Spd': 0, 'offset': 0, 'offset_time': 5}


def call_back_npc_vehicle_data(msg):
    global npc_list
    npc_list = json.loads(msg.data)


def call_back_ego_vehicle_data(msg):
    global ego_veh_dict
    ego_veh_dict = json.loads(msg.data)


def present_lane_dissatisfaction():
    global ego_veh_dict
    global content
    global is_exit
    global ck

    last_time = time.time()
    ck = 0

    while not is_exit:

        present_road_global_speed = 25
        roi_list = ROI()

        present_front_veh = roi_list[0]
        # print(present_front_veh)

        try:
            s_dis = ego_veh_dict['ego_speed'] * 1.54 + 15
        except:
            s_dis = 15
        # print('front_veh is:', present_front_veh['dy'], 's_dis', s_dis)

        if present_front_veh['dy'] < s_dis:
            if ego_veh_dict != {}:
                current_time = time.time()
                # print(present_road_global_speed, ego_veh_dict['ego_speed'])
                ck += (present_road_global_speed - ego_veh_dict['ego_speed']*3.6) / present_road_global_speed * (current_time - last_time)
                # ck += 0.1
                last_time = current_time
                time.sleep(0.2)

                print('dissatisfaction is: ', ck)
                if ck >= 1.5:
                    print("** ego want to change lane **")

            else:
                print('waiting')
        else:
            print('keep going')

        time.sleep(0.05)


def payoff_matrix_calculate(m, n):
    global ego_veh_dict
    global npc_list

    # print('ego_dict :', ego_veh_dict)
    # lane_id = ego_veh_dict['ego_lane']

    roi_list = ROI()

    present_front_veh = roi_list[0]
    target_front_veh = roi_list[1]
    try:
        u_speed_nc = (present_front_veh['npc_speed'] - ego_veh_dict['ego_speed']) / ego_veh_dict['ego_speed']
    except:
        u_speed_nc = 0
    try:
        u_speed_c = (target_front_veh['npc_speed'] - ego_veh_dict['ego_speed']) / ego_veh_dict['ego_speed']
    except:
        u_speed_c = 1

    # print('u_speed_nc: ', u_speed_nc, 'ego speed:', ego_veh_dict['ego_speed'])

    x_list, y_list = tool.one_step(3.5, 5, ego_veh_dict['ego_speed'])
    Dis_ego_to_collision_point = (min(y_list) + max(y_list)) / 2

    try:
        time_to_collision_cl = Dis_ego_to_collision_point / ego_veh_dict['ego_speed']
    except:
        time_to_collision_cl = 3

    time_thr = 3  # 3s

    target_back_veh = roi_list[3]

    Dis_npc_to_collision_point = Dis_ego_to_collision_point + abs(target_back_veh['dy'])
    # print(Dis_npc_to_collision_point, Dis_ego_to_collision_point, target_back_veh['dy'])
    # print('Dis_ego_to_collision_point', Dis_ego_to_collision_point, Dis_npc_to_collision_point)

    time_tb_na, time_tb_a = symbols('time_tb_na time_tb_a')
    # print('eq is :', target_back_veh['npc_speed'], target_back_veh['npc_acc'], Dis_npc_to_collision_point)
    time_tb_na = max(solve(target_back_veh['npc_speed'] * time_tb_na + 0.5 * target_back_veh['npc_acc']
                       * time_tb_na ** 2 - Dis_npc_to_collision_point, time_tb_na))

    tb_speed_none_avoid = target_back_veh['npc_speed'] + target_back_veh['npc_acc'] * time_tb_na
    try:
        q_speed_na = (tb_speed_none_avoid - target_back_veh['npc_speed']) / target_back_veh['npc_speed']
    except:
        q_speed_na = 0

    npc_assume_avoid_acc = -0.1
    time_tb_a = min(solve(target_back_veh['npc_speed'] * time_tb_a + 0.5 * npc_assume_avoid_acc
                      * time_tb_a ** 2 - Dis_npc_to_collision_point, time_tb_a))

    # print('time_tb_na', time_tb_na, 'time_tb_a', time_tb_a, 'time ego', time_to_collision_cl)
    # print('time_tb_a', time_tb_a)
    tb_speed_avoid = target_back_veh['npc_speed'] + npc_assume_avoid_acc * time_tb_a
    try:
        q_speed_a = (tb_speed_avoid - target_back_veh['npc_speed']) / target_back_veh['npc_speed']
    except:
        q_speed_a = 0

    q_securty_nc_a = 1
    q_securty_nc_na = 1
    q_securty_c_a = abs(time_to_collision_cl - time_tb_a) / time_thr
    q_securty_c_na = abs(time_to_collision_cl - time_tb_na) / time_thr

    u_security_nc_a = 1
    u_security_nc_na = 1
    u_security_c_a = abs(time_to_collision_cl - time_tb_a) / time_thr
    u_security_c_na = abs(time_to_collision_cl - time_tb_na) / time_thr

    U_11 = m * u_speed_c + (1 - m) * u_security_c_a
    Q_11 = n * q_speed_a + (1 - n) * q_securty_c_a

    U_12 = m * u_speed_c + (1 - m) * u_security_c_na
    Q_12 = n * q_speed_na + (1 - n) * q_securty_c_na

    U_21 = m * u_speed_nc + (1 - m) * u_security_nc_a
    Q_21 = n * q_speed_a + (1 - n) * q_securty_nc_a

    U_22 = m * u_speed_nc + (1 - m) * u_security_nc_na
    Q_22 = n * q_speed_na + (1 - n) * q_securty_nc_na

    U_payoff_matrix = np.array([[0, 0], [0, 0]], dtype=float)
    U_payoff_matrix[0][0] = U_11
    U_payoff_matrix[0][1] = U_12
    U_payoff_matrix[1][0] = U_21
    U_payoff_matrix[1][1] = U_22

    print('q_speed_a: ', q_speed_a, 'q_speed_na: ', q_speed_na, 'q_securty_c_a', q_securty_c_a, 'q_securty_c_na', q_securty_c_na)

    Q_payoff_matrix = np.array([[0, 0], [0, 0]], dtype=float)
    Q_payoff_matrix[0][0] = Q_11
    Q_payoff_matrix[0][1] = Q_12
    Q_payoff_matrix[1][0] = Q_21
    Q_payoff_matrix[1][1] = Q_22

    print(U_payoff_matrix, '\n', Q_payoff_matrix)

    return U_payoff_matrix, Q_payoff_matrix


def Mixed_Strategy_Nash_Equilibrium():

    U_ego, Q_npc = payoff_matrix_calculate(0.5, 0.5)
    print('U Q', Q_npc, U_ego)

    u11 = U_ego[0][0]
    u12 = U_ego[0][1]
    u21 = U_ego[1][0]
    u22 = U_ego[1][1]
    q11 = Q_npc[0][0]
    q12 = Q_npc[0][1]
    q21 = Q_npc[1][0]
    q22 = Q_npc[1][1]

    a, b = symbols('a b')

    Ep_ego = (a * (b * u11 + (1 - b) * u12)) + ((1 - a) * (b * u21 + (1 - b) * u22))
    Ep_npc = (b * (a * q11 + (1 - a) * q21)) + ((1 - b) * (a * q12 + (1 - a) * q22))

    diff_ego = diff(Ep_ego, a)
    diff_npc = diff(Ep_npc, b)

    # print(diff_ego)

    npc_b = solve(diff_ego, b)[0]
    ego_a = solve(diff_npc, a)[0]

    print('pro is', ego_a, npc_b)

    return ego_a, npc_b


def nashpy_solve():
    global ck

    roi_list = ROI()
    left_rear_veh = roi_list[3]

    if ck >= 0.45:

        if (left_rear_veh['dy'] <= 0) and (left_rear_veh['dy']) > -100:
            if left_rear_veh['npc_speed'] - ego_veh_dict['ego_speed'] > 0:

                U_ego, Q_npc = payoff_matrix_calculate(0.5, 0.3)
                # print('U Q', Q_npc, U_ego)
                rps = nashpy.Game(U_ego, Q_npc)
                equilibrium = rps.support_enumeration()
                equ_list = []

                for eq in equilibrium:
                    print(eq)
                    equ_list.append(eq)
                    # equ_list.reverse()
                print(equ_list)

                if (([1., 0.]), [1., 0.]) in equ_list:
                    print('lanechange by game')
                elif (numpy.array([0., 1.]), numpy.array([0., 1.])) in equ_list:
                    print('keeplane by game')
                else:
                    print('no new decision')
            else:
                print('left vehicle speed low, pub change lane order')
        else:
            print('no left rear veh, pub chang lane order')
    else:
        pass


def obs_coordinate_conversion():
    global npc_list
    global ego_veh_dict

    if ego_veh_dict != {}:
        location_x = ego_veh_dict['ego_x']
        location_y = ego_veh_dict['ego_y']
        rotation_yaw = ego_veh_dict['ego_head']
    else:
        location_x = 0
        location_y = 0
        rotation_yaw = 0

    simple_lane_x = 1191
    simple_lane_y = 3.76

    dis_to_simple_lane = math.sqrt(math.pow(simple_lane_x - location_x, 2)
                                   + math.pow(simple_lane_y - location_y, 2))

    dx_simple_lane = (location_y * math.cos(rotation_yaw * math.pi / 180) - location_x * math.sin(
        rotation_yaw * math.pi / 180) + simple_lane_x * math.sin(rotation_yaw * math.pi / 180) - simple_lane_y
                      * math.cos(rotation_yaw * math.pi / 180))

    dy_simple_lane = -(location_x * math.cos(rotation_yaw * math.pi / 180) - location_y * math.sin(
        rotation_yaw * math.pi / 180) + simple_lane_y * math.sin(rotation_yaw * math.pi / 180) - simple_lane_x
                      * math.cos(rotation_yaw * math.pi / 180))
    # print ("dx_simple_lane :", dx_simple_lane, "dy_simple_lane :", dy_simple_lane)

    obj_list = [{"dx": dx_simple_lane,
                 "dy": dy_simple_lane,
                 "dis": dis_to_simple_lane,
                 "npc_x": simple_lane_x,
                 "npc_y": simple_lane_y,
                 "npc_speed": 0,
                 "npc_head": 0}]

    for i in range(len(npc_list)):
        vehicle_x = npc_list[i]['npc_x']
        vehicle_y = npc_list[i]['npc_y']

        dis = math.sqrt(math.pow((vehicle_x - location_x), 2) + math.pow((vehicle_y - location_y), 2))

        # veh_road_x = (location_y * math.cos(rotation_yaw * math.pi / 180) + location_x * math.sin(
        #     rotation_yaw * math.pi / 180) - vehicle_x * math.sin(rotation_yaw * math.pi / 180) - vehicle_y * math.cos(
        #     rotation_yaw * math.pi / 180))

        veh_road_x = (location_y * math.cos(rotation_yaw * math.pi / 180) - location_x * math.sin(
            rotation_yaw * math.pi / 180) + vehicle_x * math.sin(rotation_yaw * math.pi / 180) - vehicle_y * math.cos(
            rotation_yaw * math.pi / 180))

        veh_road_y = -(location_x * math.cos(rotation_yaw * math.pi / 180) - location_y * math.sin(
            rotation_yaw * math.pi / 180) + vehicle_y * math.sin(rotation_yaw * math.pi / 180) - vehicle_x * math.cos(
            rotation_yaw * math.pi / 180))

        npc_veh = {"npc_x": npc_list[i]['npc_x'],
                   "npc_y": npc_list[i]['npc_y'],
                   "npc_speed": npc_list[i]['npc_speed'],
                   "dx": veh_road_x,
                   "dy": veh_road_y,
                   "dis": dis,
                   "npc_head": npc_list[i]["npc_head"],
                   "npc_id": npc_list[i]['npc_id'],
                   "npc_acc": npc_list[i]['npc_acc']}
        obj_list.append(npc_veh)
    return obj_list


def ROI():

    obj_list = obs_coordinate_conversion()
    # print(obj_list)


    front_obj_list = []
    left_front_obj_list = []
    right_front_obj_list = []
    left_rear_obj_list = []
    right_rear_obj_list = []

    front_dis = 1000  # m
    left_front_dis = 1000
    right_front_dis = 1000
    left_rear_dis = 1000
    right_rear_dis = 1000

    front_veh = {'npc_speed': 30, 'dx': 0, 'dy': 100, 'npc_acc': 0}
    left_front_veh = {'npc_speed': 30, 'dx': -3, 'dy': 100, 'npc_acc': 0}
    right_front_veh = {'npc_speed': 30, 'dx': 3, 'dy': 100, 'npc_acc': 0}
    left_rear_veh = {'npc_speed': 30, 'dx': -3, 'dy': -100, 'npc_acc': 0}
    right_rear_veh = {'npc_speed': 30, 'dx': -3, 'dy': -100, 'npc_acc': 0}

    if len(obj_list) != 0:

        for i in range(len(obj_list)):

            if ((obj_list[i]["dx"] < 1.2) & (obj_list[i]["dx"] > -1.2)
                    & (obj_list[i]["dy"] < 100) & (obj_list[i]["dy"] > 0)):
                front_obj_list.append(obj_list[i])

            if ((obj_list[i]["dx"] < -2.4) & (obj_list[i]["dx"] > -4.8)
                    & (obj_list[i]["dy"] < 100) & (obj_list[i]["dy"] > 0)):
                left_front_obj_list.append(obj_list[i])

            if ((obj_list[i]["dx"] < -2.4) & (obj_list[i]["dx"] > -4.8)
                    & (obj_list[i]["dy"] < 0) & (obj_list[i]["dy"] > -100)):
                left_rear_obj_list.append(obj_list[i])

            if ((obj_list[i]["dx"] < 4.8) & (obj_list[i]["dx"] > 2.4)
                    & (obj_list[i]["dy"] < 100) & (obj_list[i]["dy"] > 0)):
                right_front_obj_list.append(obj_list[i])

            if ((obj_list[i]["dx"] < 4.8) & (obj_list[i]["dx"] > 2.4)
                    & (obj_list[i]["dy"] < 100) & (obj_list[i]["dy"] > 0)):
                right_rear_obj_list.append(obj_list[i])

    if len(front_obj_list) > 0:
        for j in range(len(front_obj_list)):
            if math.sqrt(math.pow(front_obj_list[j]["dx"], 2) +
                         math.pow(front_obj_list[j]["dy"], 2)) < front_dis:
                front_dis = math.sqrt(math.pow(front_obj_list[j]["dx"], 2) +
                                      math.pow(front_obj_list[j]["dy"], 2))
                front_veh = front_obj_list[j]  # front_veh.dx & dy & front_veh.vx & vy

    if len(left_front_obj_list) > 0:
        for k in range(len(left_front_obj_list)):
            if math.sqrt(math.pow(left_front_obj_list[k]["dx"], 2) +
                         math.pow(left_front_obj_list[k]["dy"], 2)) < left_front_dis:
                left_front_dis = math.sqrt(math.pow(left_front_obj_list[k]["dx"], 2) +
                                          math.pow(left_front_obj_list[k]["dy"], 2))
                left_front_veh = left_front_obj_list[k]

    if len(right_front_obj_list) > 0:
        for k in range(len(right_front_obj_list)):
            if math.sqrt(math.pow(right_front_obj_list[k]["dx"], 2) +
                         math.pow(right_front_obj_list[k]["dy"], 2)) < right_front_dis:
                right_front_dis = math.sqrt(math.pow(right_front_obj_list[k]["dx"], 2) +
                                           math.pow(right_front_obj_list[k]["dy"], 2))
                right_front_veh = right_front_obj_list[k]

    if len(left_rear_obj_list) > 0:
        for k in range(len(left_rear_obj_list)):
            if math.sqrt(math.pow(left_rear_obj_list[k]["dx"], 2) +
                         math.pow(left_rear_obj_list[k]["dy"], 2)) < left_rear_dis:
                left_rear_dis = math.sqrt(math.pow(left_rear_obj_list[k]["dx"], 2) +
                                          math.pow(left_rear_obj_list[k]["dy"], 2))
                left_rear_veh = left_rear_obj_list[k]

    if len(right_rear_obj_list) > 0:
        for k in range(len(right_rear_obj_list)):
            if math.sqrt(math.pow(right_rear_obj_list[k]["dx"], 2) +
                         math.pow(right_rear_obj_list[k]["dy"], 2)) < right_rear_dis:
                right_rear_dis = math.sqrt(math.pow(right_rear_obj_list[k]["dx"], 2) +
                                          math.pow(right_rear_obj_list[k]["dy"], 2))
                right_rear_veh = right_rear_obj_list[k]

    return front_veh, left_front_veh, right_front_veh, left_rear_veh, right_rear_veh


def signal_handler(signal, frame):
    global is_exit
    is_exit = True


def main():
    signal.signal(signal.SIGINT, signal_handler)
    rospy.init_node('game', anonymous=False)
    rospy.Subscriber('/npc/list', std_msgs.msg.String, call_back_npc_vehicle_data)
    rospy.Subscriber('/carla/data', std_msgs.msg.String, call_back_ego_vehicle_data)
    time.sleep(0.5)

    add_thread = threading.Thread(target=present_lane_dissatisfaction)
    add_thread.start()

    while not is_exit:
        nashpy_solve()
        # payoff_matrix_calculate(0.5, 0.5)
        time.sleep(0.05)


if __name__ == '__main__':
    main()
