import math


def deg_to_rad(deg):
    rad = deg * math.pi / 180
    return rad


def Relative_distance(a, b, c, d):
    dis = math.sqrt(math.pow((a - c), 2) + math.pow((b - d), 2))
    return dis


def one_step(target_offset, target_offset_time, cur_speed):
    x_list = []
    y_list = []
    for dt in range(target_offset_time):
        dt = dt + 1
        x_list.append(((10 * (math.pow(dt, 3)) / math.pow(target_offset_time, 3)
                       - 15 * (math.pow(dt, 4)) / math.pow(target_offset_time, 4))
                      + 6 * (math.pow(dt, 5)) / math.pow(target_offset_time, 5)) * target_offset)
        y_list.append(cur_speed * dt)
    return x_list, y_list


def ROI(obj_list):

    front_obj_list = []
    left_front_obj_list = []
    right_front_obj_list = []
    left_rear_obj_list = []
    right_rear_obj_list = []

    front_dis = 1000  # m
    left_front_dis = 1000
    right_front_dis = 1000
    left_rear_dis = 1000
    right_rear_dis = 1000

    front_veh = {'npc_speed': 30, 'dx': 0, 'dy': 100, 'npc_acc': 0}
    left_front_veh = {'npc_speed': 30, 'dx': -3, 'dy': 100, 'npc_acc': 0}
    right_front_veh = {'npc_speed': 30, 'dx': 3, 'dy': 100, 'npc_acc': 0}
    left_rear_veh = {'npc_speed': 30, 'dx': -3, 'dy': -100, 'npc_acc': 0}
    right_rear_veh = {'npc_speed': 30, 'dx': -3, 'dy': -100, 'npc_acc': 0}

    if len(obj_list) != 0:

        for i in range(len(obj_list)):

            if ((obj_list[i]["dx"] < 1.2) & (obj_list[i]["dx"] > -1.2)
                    & (obj_list[i]["dy"] < 100) & (obj_list[i]["dy"] > 0)):
                front_obj_list.append(obj_list[i])

            if ((obj_list[i]["dx"] < -2.4) & (obj_list[i]["dx"] > -4.8)
                    & (obj_list[i]["dy"] < 100) & (obj_list[i]["dy"] > 0)):
                left_front_obj_list.append(obj_list[i])

            if ((obj_list[i]["dx"] < -2.4) & (obj_list[i]["dx"] > -4.8)
                    & (obj_list[i]["dy"] < 0) & (obj_list[i]["dy"] > -100)):
                left_rear_obj_list.append(obj_list[i])

            if ((obj_list[i]["dx"] < 4.8) & (obj_list[i]["dx"] > 2.4)
                    & (obj_list[i]["dy"] < 100) & (obj_list[i]["dy"] > 0)):
                right_front_obj_list.append(obj_list[i])

            if ((obj_list[i]["dx"] < 4.8) & (obj_list[i]["dx"] > 2.4)
                    & (obj_list[i]["dy"] < 100) & (obj_list[i]["dy"] > 0)):
                right_rear_obj_list.append(obj_list[i])

    if len(front_obj_list) > 0:
        for j in range(len(front_obj_list)):
            if math.sqrt(math.pow(front_obj_list[j]["dx"], 2) +
                         math.pow(front_obj_list[j]["dy"], 2)) < front_dis:
                front_dis = math.sqrt(math.pow(front_obj_list[j]["dx"], 2) +
                                      math.pow(front_obj_list[j]["dy"], 2))
                front_veh = front_obj_list[j]  # front_veh.dx & dy & front_veh.vx & vy

    if len(left_front_obj_list) > 0:
        for k in range(len(left_front_obj_list)):
            if math.sqrt(math.pow(left_front_obj_list[k]["dx"], 2) +
                         math.pow(left_front_obj_list[k]["dy"], 2)) < left_front_dis:
                left_front_dis = math.sqrt(math.pow(left_front_obj_list[k]["dx"], 2) +
                                          math.pow(left_front_obj_list[k]["dy"], 2))
                left_front_veh = left_front_obj_list[k]

    if len(right_front_obj_list) > 0:
        for k in range(len(right_front_obj_list)):
            if math.sqrt(math.pow(right_front_obj_list[k]["dx"], 2) +
                         math.pow(right_front_obj_list[k]["dy"], 2)) < right_front_dis:
                right_front_dis = math.sqrt(math.pow(right_front_obj_list[k]["dx"], 2) +
                                           math.pow(right_front_obj_list[k]["dy"], 2))
                right_front_veh = right_front_obj_list[k]

    if len(left_rear_obj_list) > 0:
        for k in range(len(left_rear_obj_list)):
            if math.sqrt(math.pow(left_rear_obj_list[k]["dx"], 2) +
                         math.pow(left_rear_obj_list[k]["dy"], 2)) < left_rear_dis:
                left_rear_dis = math.sqrt(math.pow(left_rear_obj_list[k]["dx"], 2) +
                                          math.pow(left_rear_obj_list[k]["dy"], 2))
                left_rear_veh = left_rear_obj_list[k]

    if len(right_rear_obj_list) > 0:
        for k in range(len(right_rear_obj_list)):
            if math.sqrt(math.pow(right_rear_obj_list[k]["dx"], 2) +
                         math.pow(right_rear_obj_list[k]["dy"], 2)) < right_rear_dis:
                right_rear_dis = math.sqrt(math.pow(right_rear_obj_list[k]["dx"], 2) +
                                          math.pow(right_rear_obj_list[k]["dy"], 2))
                left_rear_veh = right_rear_obj_list[k]

    return front_veh, left_front_veh, right_front_veh, left_rear_veh, right_rear_veh


def obs_coordinate_conversion(npc_list, ego_veh_dict):
    if ego_veh_dict != {}:
        location_x = ego_veh_dict['ego_x']
        location_y = ego_veh_dict['ego_y']
        rotation_yaw = ego_veh_dict['ego_head']
    else:
        location_x = 0
        location_y = 0
        rotation_yaw = 0

    simple_lane_x = 1191
    simple_lane_y = 3.76

    dis_to_simple_lane = math.sqrt(math.pow(simple_lane_x - location_x, 2)
                                   + math.pow(simple_lane_y - location_y, 2))

    dx_simple_lane = (location_y * math.cos(rotation_yaw * math.pi / 180) - location_x * math.sin(
        rotation_yaw * math.pi / 180) + simple_lane_x * math.sin(rotation_yaw * math.pi / 180) - simple_lane_y
                      * math.cos(rotation_yaw * math.pi / 180))

    dy_simple_lane = -(location_x * math.cos(rotation_yaw * math.pi / 180) - location_y * math.sin(
        rotation_yaw * math.pi / 180) + simple_lane_y * math.sin(rotation_yaw * math.pi / 180) - simple_lane_x
                      * math.cos(rotation_yaw * math.pi / 180))
    # print ("dx_simple_lane :", dx_simple_lane, "dy_simple_lane :", dy_simple_lane)

    obj_list = [{"dx": dx_simple_lane,
                 "dy": dy_simple_lane,
                 "dis": dis_to_simple_lane,
                 "npc_x": simple_lane_x,
                 "npc_y": simple_lane_y,
                 "npc_speed": 0,
                 "npc_head": 0}]

    if len(obj_list) > 1:
        for i in range(len(npc_list)):
            vehicle_x = npc_list[i]['npc_x']
            vehicle_y = npc_list[i]['npc_y']

            dis = math.sqrt(math.pow((vehicle_x - location_x), 2) + math.pow((vehicle_y - location_y), 2))

            # veh_road_x = (location_y * math.cos(rotation_yaw * math.pi / 180) + location_x * math.sin(
            #     rotation_yaw * math.pi / 180) - vehicle_x * math.sin(rotation_yaw * math.pi / 180) - vehicle_y * math.cos(
            #     rotation_yaw * math.pi / 180))

            veh_road_x = (location_y * math.cos(rotation_yaw * math.pi / 180) - location_x * math.sin(
                rotation_yaw * math.pi / 180) + vehicle_x * math.sin(rotation_yaw * math.pi / 180) - vehicle_y * math.cos(
                rotation_yaw * math.pi / 180))

            veh_road_y = -(location_x * math.cos(rotation_yaw * math.pi / 180) - location_y * math.sin(
                rotation_yaw * math.pi / 180) + vehicle_y * math.sin(rotation_yaw * math.pi / 180) - vehicle_x * math.cos(
                rotation_yaw * math.pi / 180))

            npc_veh = {"npc_x": npc_list[i]['npc_x'],
                       "npc_y": npc_list[i]['npc_y'],
                       "npc_speed": npc_list[i]['npc_speed'],
                       "dx": veh_road_x,
                       "dy": veh_road_y,
                       "dis": dis,
                       "npc_head": npc_list[i]["npc_head"],
                       "npc_id": npc_list[i]['npc_id']}
            obj_list.append(npc_veh)
    return obj_list


