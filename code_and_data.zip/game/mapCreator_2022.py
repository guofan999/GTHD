import sys
import zmq
sys.path.append('../libs')
from proContext import *
from UTM import *
import time
import thread
import numpy
import Tkinter as tk
import tkFont
import time
import signal

road,lane,left,right,spd = -1,-1,-1,-1,-1
temp_road, temp_lane, temp_left, temp_right, temp_spd = -1,-1,-1,-1,-1
lst = (0,0,0,0)
maps = []
is_exit = False

def main():
    global road,lane,left,right,spd
    global temp_road, temp_lane, temp_left, temp_right, temp_spd
    temp_road = road
    temp_lane = lane
    temp_left = left
    temp_right = right
    temp_spd = spd

    ctx = proContext()
    sub = ctx.socket(zmq.SUB)
    sub.connect('tcp://127.0.0.1:8080')
    sub.setsockopt(zmq.SUBSCRIBE,'CurGNSS')
    content = {}

    # GUI
    GUI = tk.Tk()
    GUI.title('Map Creator for autotju')
    GUI.geometry('1280x700')
    c_text = tk.Canvas(GUI, bg="white", height=700, width=300)
    c_info = tk.Canvas(GUI, bg="white", height=700, width=100)
    c_info2 = tk.Canvas(GUI, bg="white", height=700, width=100)
    GUI_text_font = tkFont.Font(family="Arial", size="25")

    GUI_Intro = c_text.create_text(150, 50, text="Map Creator", fill='black', font=GUI_text_font)
    GUI_RoadID = c_text.create_text(150, 150, text="Q < RoadID > W", fill='black', font=GUI_text_font)
    GUI_LaneID = c_text.create_text(150, 250, text="A < LaneID > S", fill='black', font=GUI_text_font)
    GUI_Left = c_text.create_text(150, 350, text="Z < Left", fill='black', font=GUI_text_font)
    GUI_Right = c_text.create_text(150, 450, text="X < Right", fill='black', font=GUI_text_font)
    GUI_Speed = c_text.create_text(150, 550, text=", < Speed> .", fill='black', font=GUI_text_font)
    GUI_Change = c_text.create_text(150, 600, text="Enter : Next Road", fill='black', font=GUI_text_font)

    GUI_Intro = c_info.create_text(50, 50, text="NOW", fill='black', font=GUI_text_font, tags="GUI_Intro")
    GUI_road = c_info.create_text(50, 150, text=str(road), fill='black', font=GUI_text_font, tags="GUI_road")
    GUI_lane = c_info.create_text(50, 250, text=str(lane), fill='black', font=GUI_text_font, tags="GUI_lane")
    GUI_left = c_info.create_text(50, 350, text=str(left), fill='black', font=GUI_text_font, tags="GUI_left")
    GUI_right = c_info.create_text(50, 450, text=str(right), fill='black', font=GUI_text_font, tags="GUI_right")
    GUI_spd = c_info.create_text(50, 550, text=str(spd), fill='black', font=GUI_text_font, tags="GUI_spd")

    GUI_Intro2 = c_info2.create_text(50, 50, text="NEXT", fill='black', font=GUI_text_font, tags="GUI_Intro2")
    GUI_road2 = c_info2.create_text(50, 150, text=str(temp_road), fill='black', font=GUI_text_font, tags="GUI_road2")
    GUI_lane2 = c_info2.create_text(50, 250, text=str(temp_lane), fill='black', font=GUI_text_font, tags="GUI_lane2")
    GUI_left2 = c_info2.create_text(50, 350, text=str(temp_left), fill='black', font=GUI_text_font, tags="GUI_left2")
    GUI_right2 = c_info2.create_text(50, 450, text=str(temp_right), fill='black', font=GUI_text_font, tags="GUI_right2")
    GUI_spd2 = c_info2.create_text(50, 550, text=str(temp_spd), fill='black', font=GUI_text_font, tags="GUI_spd2")

    def GUI_KeyQ(key):
        global temp_road, temp_lane, temp_left, temp_right, temp_spd
        temp_road -= 1
        c_info2.delete("GUI_road2")
        GUI_road2 = c_info2.create_text(50, 150, text=str(temp_road), fill='black', font=GUI_text_font,
                                        tags="GUI_road2")

    def GUI_KeyW(key):
        global temp_road, temp_lane, temp_left, temp_right, temp_spd
        temp_road += 1
        c_info2.delete("GUI_road2")
        GUI_road2 = c_info2.create_text(50, 150, text=str(temp_road), fill='black', font=GUI_text_font,
                                        tags="GUI_road2")

    def GUI_KeyA(key):
        global temp_road, temp_lane, temp_left, temp_right, temp_spd
        temp_lane -= 1
        c_info2.delete("GUI_lane2")
        GUI_lane2 = c_info2.create_text(50, 250, text=str(temp_lane), fill='black', font=GUI_text_font,
                                        tags="GUI_lane2")

    def GUI_KeyS(key):
        global temp_road, temp_lane, temp_left, temp_right, temp_spd
        temp_lane += 1
        c_info2.delete("GUI_lane2")
        GUI_lane2 = c_info2.create_text(50, 250, text=str(temp_lane), fill='black', font=GUI_text_font,
                                        tags="GUI_lane2")

    def GUI_KeyZ(key):
        global temp_road, temp_lane, temp_left, temp_right, temp_spd
        if(temp_left < 1):
            temp_left = 1
        else:
            temp_left = 0
        c_info2.delete("GUI_left2")
        GUI_left2 = c_info2.create_text(50, 350, text=str(temp_left), fill='black', font=GUI_text_font,
                                        tags="GUI_left2")

    def GUI_KeyX(key):
        global temp_road, temp_lane, temp_left, temp_right, temp_spd
        if(temp_right < 1):
            temp_right = 1
        else:
            temp_right = 0
        c_info2.delete("GUI_right2")
        GUI_right2 = c_info2.create_text(50, 450, text=str(temp_right), fill='black', font=GUI_text_font,
                                        tags="GUI_right2")

    def GUI_KeySpdDwn(key):
        global temp_road, temp_lane, temp_left, temp_right, temp_spd
        temp_spd -= 1
        c_info2.delete("GUI_spd2")
        GUI_spd2 = c_info2.create_text(50, 550, text=str(temp_spd), fill='black', font=GUI_text_font, tags="GUI_spd2")

    def GUI_KeySpdUp(key):
        global temp_road, temp_lane, temp_left, temp_right, temp_spd
        temp_spd += 1
        c_info2.delete("GUI_spd2")
        GUI_spd2 = c_info2.create_text(50, 550, text=str(temp_spd), fill='black', font=GUI_text_font, tags="GUI_spd2")

    def GUI_KeyEnter(key):
        global temp_road, temp_lane, temp_left, temp_right, temp_spd
        global road, lane, left, right, spd
        road, lane, left, right, spd = temp_road, temp_lane, temp_left, temp_right, temp_spd
        c_info.delete("GUI_road","GUI_lane","GUI_left","GUI_right","GUI_spd")
        GUI_Intro = c_info.create_text(50, 50, text="NOW", fill='black', font=GUI_text_font, tags="GUI_Intro")
        GUI_road = c_info.create_text(50, 150, text=str(road), fill='black', font=GUI_text_font, tags="GUI_road")
        GUI_lane = c_info.create_text(50, 250, text=str(lane), fill='black', font=GUI_text_font, tags="GUI_lane")
        GUI_left = c_info.create_text(50, 350, text=str(left), fill='black', font=GUI_text_font, tags="GUI_left")
        GUI_right = c_info.create_text(50, 450, text=str(right), fill='black', font=GUI_text_font, tags="GUI_right")
        GUI_spd = c_info.create_text(50, 550, text=str(spd), fill='black', font=GUI_text_font, tags="GUI_spd")

    c_info.focus_set()
    GUI.bind_all("<q>", GUI_KeyQ)
    GUI.bind_all("<w>", GUI_KeyW)
    GUI.bind_all("<a>", GUI_KeyA)
    GUI.bind_all("<s>", GUI_KeyS)
    GUI.bind_all("<z>", GUI_KeyZ)
    GUI.bind_all("<x>", GUI_KeyX)
    GUI.bind_all("<d>", GUI_KeySpdDwn)
    GUI.bind_all("<f>", GUI_KeySpdUp)
    GUI.bind_all("<Return>", GUI_KeyEnter)

    c_map = tk.Canvas(GUI, bg="white", height=700, width=700)

    def GUI_map():
        while not is_exit:
            if(len(maps) != 0):
                maps_temp2 = []
                for i in range(len(maps)):
                    c_map.delete("MAP"+str(i))
                    maps_temp2.append(from_latlon(float(maps[i][1]), float(maps[i][0])))
                maps_temp = maps_temp2[::-1]
                ox = maps_temp[0][0]
                oy = maps_temp[0][1]
                for i in range(len(maps_temp)):
                    c_map.create_oval((maps_temp[i][0] - ox)*30+350 - 2, (maps_temp[i][1] - oy)*30 +350 - 2, (maps_temp[i][0] - ox)*30 +350 + 2,
                                      (maps_temp[i][1] - oy)*30+350 + 2, tags="MAP"+str(i))
                    #print("New point px:"+str((maps_temp[i][0] - ox)*50+350))
            time.sleep(0.3)
            #print "reflash"
        print("GUI reflash exited by Ctrl-C")


    c_text.pack(side="left")
    c_info.pack(side="left")
    c_map.pack(side="right")
    c_info2.pack(side="left")


    f = open('newmap.map','w')
    f.write('RoadID\t' + 'LaneID\t' + 'Left\t' + 'Right\t' + 'Pos\n')

    def recv():
        global lst
        while True:
            while road > -1:
                f.write(str(road) + '\t' + str(lane) + '\t' + str(left) + '\t' + str(right) + '\t' + str(spd) + '\t')
                tmp = road
                while road==tmp:
                    content = sub.recvPro()
                    now = from_latlon(float(content['Lat']), float(content['Lon']))
                    if numpy.sqrt(pow((now[0]-lst[0]),2)+pow((now[1]-lst[1]),2)) >= 0.5:
                        f.write(str(content['Lat']) + ',' + str(content['Lon']) + ','+ str(content['ego_x']) + ','+ str(content['ego_y']) + ','+ str(content['Head']) +'\t')
                        lst = now
                        maps.append((content['Lat'],content['Lon'],content['Head']))
                        if(len(maps)>30):
                            #print(len(maps))
                            maps.pop(0)
                        #print(len(maps))
                f.write('\n')
    
    def setMode():
        global road,lane,left,right,spd
        f.write('RoadID\t' + 'LaneID\t' + 'Left\t' + 'Right\t' + 'Pos\n')
        while True:
            # road,lane,left,right,spd = input()
            # test GUI
            '''
            global lst
            Lon,Lat,head = input()
            now = from_latlon(float(Lat), float(Lon))
            if numpy.sqrt(pow((now[0] - lst[0]), 2) + pow((now[1] - lst[1]), 2)) >= 0.5:
                print(numpy.sqrt(pow((now[0] - lst[0]), 2) + pow((now[1] - lst[1]), 2)))
                #f.write(str(content['Lon']) + ',' + str(content['Lat']) + ',' + str(content['Head']) + '\t')
                lst = now
                maps.append((str(Lon), str(Lat), 0))
                if (len(maps) > 30):
                    maps.pop(0)
                GUI_map()
            '''

    def testGUI():
        global road,lane,left,right,spd
        #f.write('RoadID\t' + 'LaneID\t' + 'Left\t' + 'Right\t' + 'Pos\n')

        while True:
            #road,lane,left,right,spd = input()
            # test GUI

            global lst
            Lon,Lat,head = input()
            now = from_latlon(float(Lat), float(Lon))
            #if numpy.sqrt(pow((now[0] - lst[0]), 2) + pow((now[1] - lst[1]), 2)) >= 0.5:
            print(numpy.sqrt(pow((now[0] - lst[0]), 2) + pow((now[1] - lst[1]), 2)))
            #f.write(str(content['Lon']) + ',' + str(content['Lat']) + ',' + str(content['Head']) + '\t')
            lst = now
            maps.append((str(Lon), str(Lat), 0))
            if (len(maps) > 5):
                maps.pop(0)
            print(len(maps))
            print(maps)
                #GUI_map()
                #print "Boomp"




    thread.start_new_thread(recv,())
    #thread.start_new_thread(setMode,())
    #thread.start_new_thread(testGUI, ())
    thread.start_new_thread(GUI_map, ())
    
    #i = 0
    while True:
        #i =( i + 1) % 999999
        #time.sleep(1)
        GUI.mainloop()

def signal_handler(signal, frame):
    global is_exit
    is_exit = True

if __name__ == "__main__":
    main()

