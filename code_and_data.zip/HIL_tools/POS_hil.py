''' /*************************************************
  Copyright (C), TianJian University.
  Author: Guofan
  Version 2.0
  Data: 2022.5.21
  File name: POS_hil.py
  Description: analysis the data from scaner and publish the data of ego and npc
**************************************************************/'''

import sys
import json
sys.path.append("../libs")
from proContext import *
from UTM import *
import socket
import struct
import time
import rospy
import geometry_msgs.msg
import std_msgs.msg

GnssAddr = 'tcp://*:8080'

ctx = proContext()
pub = ctx.socket(zmq.PUB)
pub.bind(GnssAddr)

rospy.init_node('carla_data_pub', anonymous=False)
carla_data_pub = rospy.Publisher('/carla/data', std_msgs.msg.String, queue_size=10);
NPC_vehicle_data = rospy.Publisher('/npc/list', std_msgs.msg.String, queue_size=10);

# Car SCANer INfO (UDP)
recv_buffer = 1024
local_addr = ('192.168.31.143', 33333)
# local_addr = ('192.168.1.147', 33333)
# local_addr = ('192.168.43.110', 33333)
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.bind(local_addr)


def main():
    ego_veh_dict = {}
    while True:
        data, addr = s.recvfrom(204800)
        try:
            sensor_fusion_temp = json.loads(data)
            lat = sensor_fusion_temp['lat0']
            lon = sensor_fusion_temp['lon0']
            head = sensor_fusion_temp['head0']
            speed = sensor_fusion_temp['speed0']
            A_n = sensor_fusion_temp['Acc']
            ego_x = sensor_fusion_temp['vehx0']
            ego_y = sensor_fusion_temp['vehy0']
            curvature = sensor_fusion_temp['curvature']
            lane_id = sensor_fusion_temp['lane_id']
            speed_x = sensor_fusion_temp['speed_x']
            speed_y = sensor_fusion_temp['speed_y']
            eye = sensor_fusion_temp['eye']
            # lidar_detected_id = sensor_fusion_temp['lidar_detected_id']
            # lidar_dict = sensor_fusion_temp['lidar_dict']

            # print('lidar : ', lidar_dict)

            ego_veh_dict = {"ego_lat": lat,
                            "ego_lon": lon,
                            "ego_x": ego_x,
                            "ego_y": ego_y,
                            "ego_head": head,
                            "ego_speed": speed,
                            "ego_acc": A_n,
                            "ego_lane": lane_id,
                            "ego_road_curvature": curvature,
                            'speed_x': speed_x,
                            'speed_y': speed_y}

            carla_data_pub.publish(json.dumps(ego_veh_dict))
            print(ego_veh_dict)
            # print(eye)
            npc_list = sensor_fusion_temp['npc_list']
            NPC_vehicle_data.publish(json.dumps(npc_list))

            pass
        except:
            print("[ERROR] Sensor fusion Recv FAILED.")

        # print("[INFO] Lat:"+str(lat))
        # print("[INFO] Lon:" + str(lon))

        content = {"Lat": lat, "Lon": lon, "Head": head, "Speed": speed*3.6, "A_n": A_n, "ego_x": ego_x, "ego_y": ego_y}
        pub.sendPro("CurGNSS", content)

    s.close()


if __name__ == '__main__':
    main()
