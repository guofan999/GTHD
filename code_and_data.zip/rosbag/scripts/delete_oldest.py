#! /usr/bin/env python3

import rospy
import os
import psutil

def delete_oldest_file(directory, num_to_delete):
    # 获取目录下所有文件的路径和创建时间
    files_with_ctime = [(os.path.join(directory, file), os.path.getctime(os.path.join(directory, file))) for file in os.listdir(directory) if os.path.isfile(os.path.join(directory, file))]

    # 按创建时间对文件进行排序
    files_with_ctime.sort(key=lambda x: x[1])

    # 仅提取排序后的文件路径
    sorted_files = [file[0] for file in files_with_ctime]

    print('sorted !!!!!!!!!!!  ', sorted_files)

    # if sorted_files:
    #     oldest_file = sorted_files[0]
    #     os.remove(oldest_file)
    #     print(f"Deleted oldest file: {oldest_file}")
    # else:
    #     print("No files to delete.")

    if sorted_files:
        for file in sorted_files[:num_to_delete]:
            try:
                os.remove(file)
                print(f"Delete: {file}")
            except OSError as e:
                print(f"Error: {file} : {e.strerror}")

def get_disk_space(path):
    disk = psutil.disk_usage(path)

    total_bytes = disk.total/(1024 ** 3)
    used_bytes = disk.used/(1024 ** 3)
    free_bytes = disk.free/(1024 ** 3)

    return total_bytes,used_bytes,free_bytes

if __name__ == "__main__":
  rospy.init_node("delete_oldest")

  directory = "/media/nvidia/a434a6cb-c6a4-49cd-8e63-e77161ce50f3/DailyBag"  # 替换为要监视的目录路径
#   directory = "/home/guofan/rosbag"  # 替换为要监视的目录路径

  threshold = 80  # 替换为硬盘空间的阈值百分比
  num_to_delete = 50 # 一次性删除的文件个数

  rate = rospy.Rate(1)

  try:
        total, used, free = get_disk_space(directory)
        percent_used = (used / total) * 100
  except:
        total = 1000
        used = 1
        free = 999
        percent_used = 0.1
  
  while not rospy.is_shutdown():
    try:
        total, used, free = get_disk_space(directory)
        percent_used = (used / total) * 100
    except:
        pass
    
    rospy.loginfo("total:%f, used:%f, free:%f, percent_free:%f",total,used,free,percent_used)
    if percent_used >= threshold:
        delete_oldest_file(directory, num_to_delete)
    else:
        print("Disk space is sufficient.")
    rospy.sleep(10) # time gap about read dirctory disk free