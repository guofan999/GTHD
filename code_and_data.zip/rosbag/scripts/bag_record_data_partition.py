#! /usr/bin/env python

import rosbag
import rospy
import argparse
import logging
from datetime import datetime
import roslib.message
from threading import Lock
import signal, sys
import os

#file_path :        /media/nvidia/a434a6cb-c6a4-49cd-8e63-e77161ce50f3

logging.basicConfig(level=logging.DEBUG)

class BagRecord(object):
  def __init__(self, output_bag, topic_infos, max_bag_size):
      self.file_path = output_bag
      self.__output_bag = self.file_path + "/" + datetime.now().strftime("%Y_%m_%d_%H_%M_%S") + ".bag"
      rospy.loginfo("name:%s",self.__output_bag)
      self.__topic_infos = topic_infos
      self.__subscribers = []
      self.__Lock = Lock()
      self.__bag = rosbag.Bag(self.__output_bag, "w")
      self.__max_bag_size = max_bag_size
      self.__current_bag_size = os.path.getsize(self.__output_bag)
      signal.signal(signal.SIGINT, self.signal_handler)

  def topic_callback(self, msg, topic):
      self.__Lock.acquire()
      try:
          # output_bag_time = datetime.now().strftime("%Y_%m_%d_%H_%M_%S") + ".bag"
          # rospy.loginfo("try:%s",f"{output_bag_time}")
          if self.__current_bag_size >= self.__max_bag_size:
              self.__bag.close()
              output_bag_time = self.file_path + "/" + datetime.now().strftime("%Y_%m_%d_%H_%M_%S") + ".bag"
              self.__output_bag = f"{output_bag_time}"
              self.__output_bag = str(output_bag_time)
              rospy.loginfo("try:%s",self.__output_bag)
              self.__bag = rosbag.Bag(self.__output_bag, "w")
              self.__current_bag_size = 0
          self.__bag.write(topic, msg, rospy.Time.now())
          self.__current_bag_size = os.path.getsize(self.__output_bag)
      except Exception as e:
          rospy.logerr("%s" %e)
      finally:        
          self.__Lock.release()

  def start_recorder(self):
    for topic, topic_type in self.__topic_infos:
      msg_class = roslib.message.get_message_class(topic_type)
      self.__subscribers.append(rospy.Subscriber(topic, msg_class, self.topic_callback, topic))

  def signal_handler(self, sig, frame):
      rospy.loginfo("ctrl+c, close bag")
      self.__Lock.acquire()
      self.__bag.close()
      self.__Lock.release()
      sys.exit(0)

def main():
  parser = argparse.ArgumentParser(description="record topic to rosbag")
  parser.add_argument("-O", "--output_bag", type=str, help="specify rosbag")
  parser.add_argument("-t", "--topics", nargs="+", type=str, help="specify topic")
  parser.add_argument("-a", "--all", action="store_true", help="record all topic")
  parser.add_argument('extra_args', nargs='*', help=argparse.SUPPRESS)
  args=parser.parse_args()  

  if not args.all and not args.topics:
    logging.error("please specify topic using -t or -a")
    return

  rospy.init_node("bag_recorder")

  if args.output_bag:
    output_bag = args.output_bag
    rospy.loginfo("args_:%s",output_bag)

  topic_infos = []
  if args.all:
    topic_infos = rospy.get_published_topics()
  elif args.topics:
    topic_infos = [(topic, msg_class) for topic, msg_class in rospy.get_published_topics() if topic in args.topics]

  # print(topic_infos)
  max_retry = 10
  retry_count = 0

  while retry_count < max_retry:
    try:

      recorder = BagRecord(output_bag, topic_infos, 1048576*1000)     #max_bag_size:set your max size of bag   1M = 1048576
      rospy.loginfo("start recorder...")
      recorder.start_recorder()
      break
    except Exception as e:
      print(f"Error: {e}")
      retry_count +=1
      print("Retrying......")
  else:
    print("Max retry reached......")

  

  rospy.spin()

if __name__ == "__main__":
  main()