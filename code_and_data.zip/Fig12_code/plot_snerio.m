figure(1)
% best_path = zeros(823,3);
best_path(:,3) = [0;atan(diff(best_path(:,2)) ./ diff(best_path(:,1)))];
npc_path(:,3) = [0;atan(diff(npc_path(:,2)) ./ diff(npc_path(:,1)))];
npc1_path(:,3) = [0;atan(diff(npc1_path(:,2)) ./ diff(npc1_path(:,1)))];
%%%
% line_reference 转化成 line_reference_sl
% line_reference_sl 中所有的l +1.75 ， -1.75 ， +5.25 ， -5.25 存在road_edge = zeros(:,4)里面
% 画这个road_edge   结束
road_edge = ones(1000, 5);
road_edge(:,1) = road_edge(:,1) * -1.75 + 0.28;
road_edge(:,2) = road_edge(:,2) * 1.75+ 0.28;
road_edge(:,3) = road_edge(:,3) * -1.75+ 0.28;
road_edge(:,4) = road_edge(:,4) * 5.25+ 0.28;
road_edge(:,5) = 1 : length(road_edge);
%%%
clf;


%% 画旁车的历史轨迹
LB = 1.205;
veh_length = 5;
LF = veh_length - LB;
W = 2.320;
CarA = [npc_path(:,1) + LF*cos(npc_path(:,3)) - W*sin(npc_path(:,3))/2, npc_path(:,2) + LF*sin(npc_path(:,3)) + W*cos(npc_path(:,3))/2];
CarB = [npc_path(:,1) - LB*cos(npc_path(:,3)) - W*sin(npc_path(:,3))/2, npc_path(:,2) - LB*sin(npc_path(:,3)) + W*cos(npc_path(:,3))/2];
CarC = [npc_path(:,1) - LB*cos(npc_path(:,3)) + W*sin(npc_path(:,3))/2, npc_path(:,2) - LB*sin(npc_path(:,3)) - W*cos(npc_path(:,3))/2];
CarD = [npc_path(:,1) + LF*cos(npc_path(:,3)) + W*sin(npc_path(:,3))/2, npc_path(:,2) + LF*sin(npc_path(:,3)) - W*cos(npc_path(:,3))/2];

for i = 1 : length(CarA(:,1))
    step = 10;
    if i/step == floor(i/step)
        plot([CarA(i,1),CarB(i,1)],[CarA(i,2),CarB(i,2)],'Color',[0.6350 0.0780 0.1840],'linewidth',1)
        hold on
        plot([CarB(i,1),CarC(i,1)],[CarB(i,2),CarC(i,2)],'Color',[0.6350 0.0780 0.1840],'linewidth',1)
        hold on
        plot([CarC(i,1),CarD(i,1)],[CarC(i,2),CarD(i,2)],'Color',[0.6350 0.0780 0.1840],'linewidth',1)
        hold on
        plot([CarD(i,1),CarA(i,1)],[CarD(i,2),CarA(i,2)],'Color',[0.6350 0.0780 0.1840],'linewidth',1)
        hold on
    end
end
%%%%特别的点
for i = 1 : length(CarA(:,1))
    if i == 1 || i == length(CarA(:,1)) || i == floor(2*length(CarA(:,1))/3) || i == floor(length(CarA(:,1))/3)
        x = [CarA(i,1),CarB(i,1),CarC(i,1),CarD(i,1)];
        y = [CarA(i,2),CarB(i,2),CarC(i,2),CarD(i,2)];
        fill(x,y,[1 0 0])
    end
end

plot(npc_path(:,1),npc_path(:,2),'Color',[0.6350 0.0780 0.1840])   %%%车辆轨迹

%% 画第三辆车的轨迹
LB = 1.205;
veh_length = 5;
LF = veh_length - LB;
W = 2.320;
CarA = [npc1_path(:,1) + LF*cos(npc1_path(:,3)) - W*sin(npc1_path(:,3))/2, npc1_path(:,2) + LF*sin(npc1_path(:,3)) + W*cos(npc1_path(:,3))/2];
CarB = [npc1_path(:,1) - LB*cos(npc1_path(:,3)) - W*sin(npc1_path(:,3))/2, npc1_path(:,2) - LB*sin(npc1_path(:,3)) + W*cos(npc1_path(:,3))/2];
CarC = [npc1_path(:,1) - LB*cos(npc1_path(:,3)) + W*sin(npc1_path(:,3))/2, npc1_path(:,2) - LB*sin(npc1_path(:,3)) - W*cos(npc1_path(:,3))/2];
CarD = [npc1_path(:,1) + LF*cos(npc1_path(:,3)) + W*sin(npc1_path(:,3))/2, npc1_path(:,2) + LF*sin(npc1_path(:,3)) - W*cos(npc1_path(:,3))/2];

for i = 1 : length(CarA(:,1))
    step = 10;
    if i/step == floor(i/step)
        plot([CarA(i,1),CarB(i,1)],[CarA(i,2),CarB(i,2)],'Color',[0.8 0.6 0.5],'linewidth',1)
        hold on
        plot([CarB(i,1),CarC(i,1)],[CarB(i,2),CarC(i,2)],'Color',[0.8 0.6 0.5],'linewidth',1)
        hold on
        plot([CarC(i,1),CarD(i,1)],[CarC(i,2),CarD(i,2)],'Color',[0.8 0.6 0.5],'linewidth',1)
        hold on
        plot([CarD(i,1),CarA(i,1)],[CarD(i,2),CarA(i,2)],'Color',[0.8 0.6 0.5],'linewidth',1)
        hold on
    end
end
%%%%特别的点
for i = 1 : length(CarA(:,1))
    if i == 1 || i == length(CarA(:,1)) || i == floor(2*length(CarA(:,1))/3) || i == floor(length(CarA(:,1))/3)
        x = [CarA(i,1),CarB(i,1),CarC(i,1),CarD(i,1)];
        y = [CarA(i,2),CarB(i,2),CarC(i,2),CarD(i,2)];
        fill(x,y,[0.8 0.6 0.5])
    end
end

plot(npc1_path(:,1),npc1_path(:,2),'Color',[0.8 0.6 0.5])   %%%车辆轨迹

%% 画本车的历史轨迹
LB = 1.205;
veh_length = 6.605;
LF = veh_length - LB;
W = 2.320;
CarA = [best_path(:,1) + LF*cos(best_path(:,3)) - W*sin(best_path(:,3))/2, best_path(:,2) + LF*sin(best_path(:,3)) + W*cos(best_path(:,3))/2];
CarB = [best_path(:,1) - LB*cos(best_path(:,3)) - W*sin(best_path(:,3))/2, best_path(:,2) - LB*sin(best_path(:,3)) + W*cos(best_path(:,3))/2];
CarC = [best_path(:,1) - LB*cos(best_path(:,3)) + W*sin(best_path(:,3))/2, best_path(:,2) - LB*sin(best_path(:,3)) - W*cos(best_path(:,3))/2];
CarD = [best_path(:,1) + LF*cos(best_path(:,3)) + W*sin(best_path(:,3))/2, best_path(:,2) + LF*sin(best_path(:,3)) - W*cos(best_path(:,3))/2];

for i = 1 : length(CarA(:,1))
    step = 8;
    if i/step == floor(i/step)
        plot([CarA(i,1),CarB(i,1)],[CarA(i,2),CarB(i,2)],'Color',[0 0.4470 0.7410],'linewidth',1)
        hold on
        plot([CarB(i,1),CarC(i,1)],[CarB(i,2),CarC(i,2)],'Color',[0 0.4470 0.7410],'linewidth',1)
        hold on
        plot([CarC(i,1),CarD(i,1)],[CarC(i,2),CarD(i,2)],'Color',[0 0.4470 0.7410],'linewidth',1)
        hold on
        plot([CarD(i,1),CarA(i,1)],[CarD(i,2),CarA(i,2)],'Color',[0 0.4470 0.7410],'linewidth',1)
        hold on
    end
end

%%特别的点
for i = 1 : length(CarA(:,1))
    if i == 1 || i == length(CarA(:,1)) || i == floor(2*length(CarA(:,1))/3) || i == floor(length(CarA(:,1))/3)
        x = [CarA(i,1),CarB(i,1),CarC(i,1),CarD(i,1)];
        y = [CarA(i,2),CarB(i,2),CarC(i,2),CarD(i,2)];
        fill(x,y,[0 0.4470 0.7410])
    end
end

plot(best_path(:,1),best_path(:,2),'Color',[0 0.4470 0.7410])   %%%车辆轨迹


%%

% plot(road_edge(:,5),road_edge(:,1),'--k','LineWidth',1)  
plot(road_edge(:,5),road_edge(:,2),'--k','LineWidth',1)  
plot(road_edge(:,5),road_edge(:,3),'k','LineWidth',2)  
plot(road_edge(:,5),road_edge(:,4),'k','LineWidth',2) 
axis equal;
axis ([640,880,-10,30])
set(gca,'xTick',640:10:880);
set(gca,'yTick',-10:10:30);
set(gca,'FontName','Times New Roman','FontSize',20,'LineWidth',0.75);
set(gca,'ticklength', [0 0]); %删除刻度线
set(gca,'linewidth',2)
xlabel('X/m','FontName','Times New Roman','FontSize',20);
ylabel('Y/m','FontName','Times New Roman','FontSize',20);
grid on;
hold on

