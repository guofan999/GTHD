import numpy as np
"""
    本函数用于贝叶斯驾驶风格实时估计
    输入：车辆信息列表[速度m/s， 加速度m/s2, 前车间距m]
    输出：风格概率列表[保守，一般，激进]
    时间：2023.3.27
"""
conservative_car_number = 4475
normal_car_number = 2572
aggressive_car_number = 2136
all_car_number = conservative_car_number + normal_car_number + aggressive_car_number
prior_probability = [conservative_car_number/all_car_number,    # 保守，一般，激进的先验概率
                     normal_car_number/all_car_number,
                     aggressive_car_number/all_car_number]

conservative_center = [3.94, 0.02, 19.4]
normal_center = [4.42, 0.03, 11.94]
aggressive_center = [5.39, 0.05, 6.4]

centers = [conservative_center, normal_center, aggressive_center]

style_msg = []
conservative_probability = []
normal_probability = []
aggressive_paobability = []

def style_judgment(data) :

    diffMat = np.tile(data, (3,1)) - centers  # 复制并计算各中心点的距离
    sqDiffMat = diffMat ** 2
    sqDisMat = sqDiffMat.sum(axis=1)  # 按行求和
    sqDisMat = list(sqDisMat)
    sum_sqDisMat = sum(sqDisMat)
    sqDisMat = [sqDisMat[0]/sum_sqDisMat, sqDisMat[1]/sum_sqDisMat, sqDisMat[2]/sum_sqDisMat]
    sqDisMat = [1/sqDisMat[0], 1/sqDisMat[1], 1/sqDisMat[2]]
    sum_sqDisMat = sum(sqDisMat)
    sqDisMat = [sqDisMat[0] / sum_sqDisMat, sqDisMat[1] / sum_sqDisMat, sqDisMat[2] / sum_sqDisMat]

    max_probability = sqDisMat.index(max(sqDisMat))
    style_msg.append(max_probability)
    if max_probability == 0 :
        print('该车辆为保守型')
    elif max_probability == 1 :
        print('该车辆为一般型')
    else :
        print('该车辆为激进型')
    print('似然函数为： ',sqDisMat)
    return sqDisMat


def Beysian_style_jduge(data):
    global prior_probability

    prior_weight = 0.9
    posterior_weight = 1-prior_weight
    posterior_probability = style_judgment(data)
    prior_probability = [prior_probability[0] * posterior_probability[0],
                         prior_probability[1] * posterior_probability[1],
                         prior_probability[2] * posterior_probability[2]]
    sum_prior_probability = sum(prior_probability)
    prior_probability = prior_probability / sum_prior_probability
    # prior_probability = prior_probability * prior_weight + posterior_probability * posterior_weight

    prior_probability = [prior_probability[i]*prior_weight + posterior_probability[i]*posterior_weight for i in range(len(prior_probability))]
    conservative_probability.append(prior_probability[0])
    normal_probability.append(prior_probability[1])
    aggressive_paobability.append(prior_probability[2])
    print(' 保守，一般，激进的概率为: ', prior_probability)
