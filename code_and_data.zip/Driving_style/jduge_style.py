"""
    本程序用于判断驾驶员风格概率分布
    采用先验乘以似然的方法得到后验概率并实现收敛
    先验概率为:
        保守型车辆总数： 4475
        一般型车辆总数： 2572
        激进型车辆综述： 2136
    聚类中心：
    类别    速度km/h    加速度m/s2    车头时距s
    保守    22.9549     0.8778      3.352
    一般    36.6022     0.9538      2.4957
    激进    51.624      1.149       2.1522
"""
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import xlwt

conservative_car_number = 4475
normal_car_number = 2572
aggressive_car_number = 2136
all_car_number = conservative_car_number + normal_car_number + aggressive_car_number
prior_probability = [conservative_car_number/all_car_number,    # 保守，一般，激进的先验概率
                     normal_car_number/all_car_number,
                     aggressive_car_number/all_car_number]

conservative_center = [22.9549, 0.8778, 3.352]
normal_center = [36.6022, 0.9538, 2.4957]
aggressive_center = [51.624, 1.149, 2.1522]
centers = [conservative_center, normal_center, aggressive_center]
style_msg = []
conservative_probability = []
normal_probability = []
aggressive_paobability = []

def getdata(xls) :
    vehicle_sheet = pd.read_excel(xls, sheet_name=0)
    nrows = vehicle_sheet.shape[0]  # 获取行数 shape[1]获取列数
    ncols = vehicle_sheet.shape[1]  # 获取列数
    veh_list = vehicle_sheet.loc[:, ['Vehicle_ID', 'v_Vel', 'v_Acc', 'Time_Hdwy']]
    data = []

    for i in range(nrows) :
        temp = []
        temp.append(veh_list['v_Vel'][i])
        temp.append(veh_list['v_Acc'][i])
        temp.append(veh_list['Time_Hdwy'][i])
        data.append(temp)

    return data,nrows  #转化成数组

def style_judgment(data) :

    diffMat = np.tile(data, (3,1)) - centers  # 复制并计算各中心点的距离
    sqDiffMat = diffMat ** 2
    sqDisMat = sqDiffMat.sum(axis=1)  # 按行求和
    sqDisMat = list(sqDisMat)
    sum_sqDisMat = sum(sqDisMat)
    sqDisMat = [sqDisMat[0]/sum_sqDisMat, sqDisMat[1]/sum_sqDisMat, sqDisMat[2]/sum_sqDisMat]
    print('sqDismat: ', sqDisMat)
    sqDisMat = [1/sqDisMat[0], 1/sqDisMat[1], 1/sqDisMat[2]]
    sum_sqDisMat = sum(sqDisMat)
    sqDisMat = [sqDisMat[0] / sum_sqDisMat, sqDisMat[1] / sum_sqDisMat, sqDisMat[2] / sum_sqDisMat]
    print('sqDismat: ', sqDisMat)

    max_probability = sqDisMat.index(max(sqDisMat))
    style_msg.append(max_probability)
    if max_probability == 0 :
        print('该车辆为保守型')
    elif max_probability == 1 :
        print('该车辆为一般型')
    else :
        print('该车辆为激进型')
    print('似然函数为： ',sqDisMat)
    return sqDisMat


if __name__ == '__main__' :
    print('程序开始')
    xls = 'vehicle_try_msg.xlsx'

    data,nrows = getdata(xls)
    step = range(nrows)
    prior_weight = 0.9
    posterior_weight = 1-prior_weight
    for nrow in range(nrows) :
        posterior_probability = style_judgment(data[nrow])
        prior_probability = [prior_probability[0] * posterior_probability[0],
                             prior_probability[1] * posterior_probability[1],
                             prior_probability[2] * posterior_probability[2]]
        sum_prior_probability = sum(prior_probability)
        prior_probability = prior_probability / sum_prior_probability
        # prior_probability = prior_probability * prior_weight + posterior_probability * posterior_weight

        prior_probability = [prior_probability[i]*prior_weight + posterior_probability[i]*posterior_weight for i in range(len(prior_probability))]
        conservative_probability.append(prior_probability[0])
        normal_probability.append(prior_probability[1])
        aggressive_paobability.append(prior_probability[2])
        print(' 保守，一般，激进的概率为: ', prior_probability)

    wb = xlwt.Workbook('encoding = utf-8')
    sheet = wb.add_sheet('驾驶风格概率分布')
    sheet.write(0, 0, 'conservative_probability')
    sheet.write(0, 1, 'normal_probability')
    sheet.write(0, 2, 'aggressive_paobability')
    for i in range(len(aggressive_paobability)) :
        sheet.write(i+1, 0, conservative_probability[i])
        sheet.write(i+1, 1, normal_probability[i])
        sheet.write(i+1, 2, aggressive_paobability[i])
    wb.save('style_probability.xls')

    # plt.plot(step,style_msg,color = 'red',label = 'style_msg')
    plt.plot(step, conservative_probability, color="blue", label="conservative_probability")
    plt.plot(step, normal_probability, color="green", label="normal_probability")
    plt.plot(step, aggressive_paobability, color="orange", label="aggressive_paobability")

    plt.legend()  # 显示图例
    # plt.xlabel("step")
    # plt.ylabel("task_number")
    # plt.title("随着时间变化的相应的任务个数")
    plt.show()  # 画图









