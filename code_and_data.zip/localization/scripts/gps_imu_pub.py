#!/usr/bin/python3
# -*- coding: utf-8 -*-

# 作者：

# 功能描述：
# 通过can协议（dbc文件）解析组合惯导数据
# 按照Gps.msg数据类型进行发布

import can
import cantools
import rospy
import rosparam
from msg_gen.msg import Gps
from msg_gen.msg import pose
import math
import std_msgs
import os
from datetime import datetime, timedelta
import time
import json
import threading

content = {'Lat': 0, 'Lon': 0, 'Head': 0, 'Spead': 0,
           'UTM_x': 0, 'UTM_y': 0}  

slam_MSG = pose()

def from_latlon(latitude, longitude, force_zone_number=None):

    """This function convert Latitude and Longitude to UTM coordinate

        Parameters
        ----------
        latitude: float
            Latitude between 80 deg S and 84 deg N, e.g. (-80.0 to 84.0)

        longitude: float
            Longitude between 180 deg W and 180 deg E, e.g. (-180.0 to 180.0).

        force_zone number: int
            Zone Number is represented with global map numbers of an UTM Zone
            Numbers Map. You may force conversion including one UTM Zone Number.
            More information see UTMzones [1]_

       .. _[1]: http://www.jaworski.ca/UTMzones.htm
    """
    #__all__ = ['to_latlon', 'from_latlon']

    K0 = 0.9996

    E = 0.00669438
    E2 = E * E
    E3 = E2 * E
    E_P2 = E / (1.0 - E)

    SQRT_E = math.sqrt(1 - E)
    _E = (1 - SQRT_E) / (1 + SQRT_E)
    _E2 = _E * _E
    _E3 = _E2 * _E
    _E4 = _E3 * _E
    _E5 = _E4 * _E

    M1 = (1 - E / 4 - 3 * E2 / 64 - 5 * E3 / 256)
    M2 = (3 * E / 8 + 3 * E2 / 32 + 45 * E3 / 1024)
    M3 = (15 * E2 / 256 + 45 * E3 / 1024)
    M4 = (35 * E3 / 3072)

    P2 = (3. / 2 * _E - 27. / 32 * _E3 + 269. / 512 * _E5)
    P3 = (21. / 16 * _E2 - 55. / 32 * _E4)
    P4 = (151. / 96 * _E3 - 417. / 128 * _E5)
    P5 = (1097. / 512 * _E4)

    R = 6378137

    ZONE_LETTERS = "CDEFGHJKLMNPQRSTUVWXX"

    if not -80.0 <= latitude <= 84.0:
        raise OutOfRangeError('latitude out of range (must be between 80 deg S and 84 deg N)')
    if not -180.0 <= longitude <= 180.0:
        raise OutOfRangeError('longitude out of range (must be between 180 deg W and 180 deg E)')

    lat_rad = math.radians(latitude)
    lat_sin = math.sin(lat_rad)
    lat_cos = math.cos(lat_rad)

    lat_tan = lat_sin / lat_cos
    lat_tan2 = lat_tan * lat_tan
    lat_tan4 = lat_tan2 * lat_tan2

    if force_zone_number is None:
        zone_number = latlon_to_zone_number(latitude, longitude)
    else:
        zone_number = force_zone_number

    zone_letter = latitude_to_zone_letter(latitude)

    lon_rad = math.radians(longitude)
    central_lon = zone_number_to_central_longitude(zone_number)
    central_lon_rad = math.radians(central_lon)

    n = R / math.sqrt(1 - E * lat_sin ** 2)
    c = E_P2 * lat_cos ** 2

    a = lat_cos * (lon_rad - central_lon_rad)
    a2 = a * a
    a3 = a2 * a
    a4 = a3 * a
    a5 = a4 * a
    a6 = a5 * a

    m = R * (M1 * lat_rad -
             M2 * math.sin(2 * lat_rad) +
             M3 * math.sin(4 * lat_rad) -
             M4 * math.sin(6 * lat_rad))

    easting = K0 * n * (a +
                        a3 / 6 * (1 - lat_tan2 + c) +
                        a5 / 120 * (5 - 18 * lat_tan2 + lat_tan4 + 72 * c - 58 * E_P2)) + 500000

    northing = K0 * (m + n * lat_tan * (a2 / 2 +
                                        a4 / 24 * (5 - lat_tan2 + 9 * c + 4 * c ** 2) +
                                        a6 / 720 * (61 - 58 * lat_tan2 + lat_tan4 + 600 * c - 330 * E_P2)))

    if latitude < 0:
        northing += 10000000

    return easting, northing, zone_number, zone_letter


def latitude_to_zone_letter(latitude):
    ZONE_LETTERS = "CDEFGHJKLMNPQRSTUVWXX"
    if -80 <= latitude <= 84:
        return ZONE_LETTERS[int(latitude + 80) >> 3]
    else:
        return None


# 0-360 ->  -pi - pi
def angle_2_angle(angle):
    angle -= 90
    while (angle < -180):
        angle = angle + 360
    while (angle > 180):
        angle = angle - 360
    return -angle


# deg -> rad
def deg_2_rad(angle):
    return angle * math.pi / 180

def UTM_local_change(utm_x, utm_y, dis_local_x, dis_local_y, theta):
    theta_to_ego = math.atan2(dis_local_x, dis_local_y) * 180 / math.pi
    dis_local = math.sqrt(math.pow(dis_local_x, 2) + math.pow(dis_local_y, 2))
    alpha = math.pi * (theta + theta_to_ego) / 180
    utm_x_change_local = utm_x + dis_local * math.cos(alpha)
    utm_y_change_local = utm_y + dis_local * math.sin(alpha)

    return utm_x_change_local, utm_y_change_local

def UTM_local_change1(utm_x, utm_y, dis_local_x, dis_local_y, theta):

    dis_local = dis_local_y
    alpha = theta * math.pi / 180
    utm_x_change_local = utm_x - dis_local * math.cos(alpha)
    utm_y_change_local = utm_y - dis_local * math.sin(alpha)

    return utm_x_change_local, utm_y_change_local

def latlon_to_zone_number(latitude, longitude):
    if 56 <= latitude < 64 and 3 <= longitude < 12:
        return 32

    if 72 <= latitude <= 84 and longitude >= 0:
        if longitude <= 9:
            return 31
        elif longitude <= 21:
            return 33
        elif longitude <= 33:
            return 35
        elif longitude <= 42:
            return 37

    return int((longitude + 180) / 6) + 1


def zone_number_to_central_longitude(zone_number):
    return (zone_number - 1) * 6 - 180 + 3


def gps_week_seconds_to_utc(gpsweek, gpsseconds, leapseconds=18):
    datetimeformat = "%Y-%m-%d %H:%M:%S.%f"
    gpsseconds = gpsseconds / 1000

    epoch = datetime.strptime("1980-01-06 08:00:00.000", datetimeformat)
    # timedelta函数会处理seconds为负数的情况
    elapsed = timedelta(days=(gpsweek * 7), seconds=(gpsseconds - leapseconds))
    beijing_time = datetime.strftime(epoch + elapsed, datetimeformat)
    time_stamp = int((time.mktime(datetime.strptime(beijing_time, "%Y-%m-%d %H:%M:%S.%f").timetuple())))

    return beijing_time, time_stamp


def call_back_from_slam(msg):
    global slam_MSG

    slam_MSG = msg
        

def main():
    global lat_last
    global lon_last
    global GPS_MSG
    global slam_MSG

    rospy.init_node("gps_imu_pub")
    pub = rospy.Publisher('/gps_imu', Gps, queue_size=10)
    # pub_sun = rospy.Publisher('CurGNSS', std_msgs.msg.String, queue_size=10)
    rospy.Subscriber('/world_pose', pose, call_back_from_slam)
    gps_can_channel = rosparam.get_param('/gps_can_channel')
    work_space_name = rosparam.get_param('/work_space_name')

    old_path = os.path.abspath('.')
    new_path = old_path.replace(".ros", work_space_name )
    gps_dbc_file = os.path.join(new_path, 'src/perception/localization/config/kuangka_gnss.dbc')
    offset_x = rosparam.get_param('/offset_x')
    offset_y = rosparam.get_param('/offset_y')

    db = cantools.db.load_file(gps_dbc_file)

    GPS_MSG = Gps()
    slam_MSG.slam_reliability == 0
    dis_local_x = 0
    dis_local_y = -4.350
    Cycle_flag = False
    use_slam = False
    if os.path.exists(gps_dbc_file):
        print("找到文件")
    else:
        print("未找到文件")
        dir_path = os.path.dirname(os.path.abspath(__file__))
        gps_dbc_file = os.path.join(dir_path, gps_dbc_file)
        if os.path.exists(gps_dbc_file):
            print("找到文件")
        else:
            print("仍未找到文件")

    try:
        bus = can.interface.Bus(channel=gps_can_channel, bustype='socketcan')
        # bus = can.interface.Bus(channel= 'can1', bustype='socketcan')
        connect_flag = True
    except:
        connect_flag = False
    # print('hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh')
    while not connect_flag:
        GPS_MSG.state = False
        pub.publish(GPS_MSG)
        print("Gps Can disconnenct")
        try:
            bus = can.interface.Bus(channel=gps_can_channel, bustype='socketcan')
            connect_flag = True
        except:
            connect_flag = False

        print('error1')

    try:
        while connect_flag:
            
            print('error2')
            message = bus.recv()
            print('origin data', message)
            GPS_MSG.header.stamp = rospy.Time.now()

            # if message.arbitration_id == 0x320:
            #     decoded_message = db.decode_message(message.arbitration_id, message.data)
            # #     GPS_MSG.gps_time = gps_week_seconds_to_utc(int(decoded_message["GpsWeek"]),
            # #                                                 int(decoded_message["GpsTime"]))[1]
            #     print("time", decoded_message)

            if message.arbitration_id == 0x321:
                decoded_message = db.decode_message(message.arbitration_id, message.data)
                GPS_MSG.AngRateRawZ = decoded_message["AngRateRawZ"]

            elif message.arbitration_id == 0x323:
                decoded_message = db.decode_message(message.arbitration_id, message.data)
                GPS_MSG.system_state = decoded_message["system_state"]
                GPS_MSG.GpsNumSatsUsed = decoded_message["GpsNumSatsUsed"]
                GPS_MSG.GpsNumSats2Used = decoded_message["GpsNumSats2Used"]
                GPS_MSG.GpsAge = decoded_message["GpsAge"]
                GPS_MSG.GpsNumSats = decoded_message["GpsNumSats"]
                GPS_MSG.GpsNumSats2 = decoded_message["GpsNumSats2"]
                GPS_MSG.satellite_status = decoded_message["satellite_status"]

                

                if int(decoded_message["satellite_status"]) == 4:
                    GPS_MSG.state = True
                    use_slam = False
                else:   
                    GPS_MSG.state = False
                    use_slam = True
                    

            elif message.arbitration_id == 0x325:
                decoded_message = db.decode_message(message.arbitration_id, message.data)
                print(decoded_message)
                GPS_MSG.PosAlt = decoded_message["PosAlt"]
                GPS_MSG.posZ = GPS_MSG.PosAlt

            elif message.arbitration_id == 0x327:
                decoded_message = db.decode_message(message.arbitration_id, message.data)
                GPS_MSG.Vel = decoded_message["Vel"] * 3.6
                GPS_MSG.speed = decoded_message["Vel"] * 3.6
                #0805

            elif message.arbitration_id == 0x329:
                decoded_message = db.decode_message(message.arbitration_id, message.data)
                GPS_MSG.AccelX = decoded_message["AccelX"]
                GPS_MSG.AccelY =  decoded_message["AccelY"]
                GPS_MSG.AccelZ = decoded_message["AccelZ"]

            elif message.arbitration_id == 0X31D:
                decoded_message = db.decode_message(message.arbitration_id, message.data)
                GPS_MSG.AngleRoll = decoded_message["AngleRoll"]
                GPS_MSG.AnglePitch = decoded_message["AnglePitch"]
                GPS_MSG.AngleHeading = angle_2_angle(decoded_message["AngleHeading"])
                GPS_MSG.oriZ = GPS_MSG.AngleHeading
                if GPS_MSG.AnglePitch < -1.8376502:
                    GPS_MSG.hill = -1
                elif GPS_MSG.AnglePitch > 2.22225247:
                    GPS_MSG.hill = 1
                else:
                    GPS_MSG.hill = 0
            

            elif message.arbitration_id == 0x31E:
                decoded_message = db.decode_message(message.arbitration_id, message.data)
                GPS_MSG.PosLon = decoded_message["PosLon2"]
                GPS_MSG.lon = decoded_message["PosLon2"]
                # lon_last = GPS_MSG.PosLon

            elif message.arbitration_id == 0x31F:
                Cycle_flag = True
                decoded_message = db.decode_message(message.arbitration_id, message.data)
                GPS_MSG.PosLat = decoded_message["PosLat2"]
                GPS_MSG.lat = decoded_message["PosLat2"]
                # lat_last = GPS_MSG.PosLat


            # elif message.arbitration_id == 0x324:
            #     Cycle_flag = True
            #     decoded_message = db.decode_message(message.arbitration_id, message.data)
            #     GPS_MSG.PosLon = decoded_message["PosLon"]
            #     GPS_MSG.lon = decoded_message["PosLon"]
            #     decoded_message = db.decode_message(message.arbitration_id, message.data)
            #     GPS_MSG.PosLat = decoded_message["PosLat"]
            #     GPS_MSG.lat = decoded_message["PosLat"]
    
            if use_slam == True and slam_MSG.state == 1:
            # if slam_MSG.slam_reliability == 1 and Cycle_flag == True:
                GPS_MSG.state = True
                print("slam!!")

                GPS_MSG.posX = slam_MSG.x
                GPS_MSG.posY = slam_MSG.y
                GPS_MSG.posZ = slam_MSG.z

                GPS_MSG.AngleRoll = slam_MSG.roll
                GPS_MSG.AnglePitch = slam_MSG.pitch
                GPS_MSG.AngleHeading = slam_MSG.yaw
                GPS_MSG.oriZ = GPS_MSG.AngleHeading

            else:

                GPS_MSG.posX = from_latlon(GPS_MSG.PosLat, GPS_MSG.PosLon)[0] - offset_x
                GPS_MSG.posY = from_latlon(GPS_MSG.PosLat, GPS_MSG.PosLon)[1] - offset_y
                # print(from_latlon(GPS_MSG.PosLat, GPS_MSG.PosLon)[0], from_latlon(GPS_MSG.PosLat, GPS_MSG.PosLon)[1])
            GPS_MSG.Rear_posX = UTM_local_change(GPS_MSG.posX, GPS_MSG.posY, dis_local_x, dis_local_y, GPS_MSG.AngleHeading)[0]
            GPS_MSG.Rear_posY = UTM_local_change(GPS_MSG.posX, GPS_MSG.posY, dis_local_x, dis_local_y, GPS_MSG.AngleHeading)[1]
            # GPS_MSG.Rear_posX_1 = UTM_local_change1(GPS_MSG.posX, GPS_MSG.posY, dis_local_x, dis_local_y, GPS_MSG.AngleHeading)[0]
            # GPS_MSG.Rear_posY_1 = UTM_local_change1(GPS_MSG.posX, GPS_MSG.posY, dis_local_x, dis_local_y, GPS_MSG.AngleHeading)[1]
            GPS_MSG.Rear_posZ = GPS_MSG.posZ
            
            if Cycle_flag:
                # pub_sun.publish(json.dumps(content))
                # print(content)

                pub.publish(GPS_MSG)
                Cycle_flag = False
                print("pub ok")
            # time.sleep(0.02)
        rospy.spin()
        
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
