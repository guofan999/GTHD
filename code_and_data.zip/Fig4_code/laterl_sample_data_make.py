import math
import numpy as np
import csv
import pandas as pd


def one_step(target_offset, target_offset_time):
    x_list = []

    start = 0
    delta = target_offset_time/50

    length = int((target_offset_time - start) / delta)
    time_list = [start + x * (target_offset_time - start) / length for x in range(length)]
    if time_list[-1] + delta > target_offset_time:
        pass
    else:
        time_list.append(time_list[-1] + delta)

    for dt in time_list:

        x_list.append(((10 * (math.pow(dt, 3)) / math.pow(target_offset_time, 3)
                       - 15 * (math.pow(dt, 4)) / math.pow(target_offset_time, 4))
                      + 6 * (math.pow(dt, 5)) / math.pow(target_offset_time, 5)) * target_offset)

    return x_list, time_list


lane_keep_offset_list = [-0.1, 0, 0.1]
lane_change_offset_list = [3.3, 3.4, 3.5, 3.6, 3.7]
target_time_list = [3.48, 4.16, 4.84, 5.52, 6.2]


lane_348_dict = {}
for j in lane_keep_offset_list:
    lane_348_dict[str(j)] = one_step(j, target_time_list[0])[0]
for k in lane_change_offset_list:
    lane_348_dict[str(k)] = one_step(k, target_time_list[0])[0]
    time_348_list = one_step(k, target_time_list[0])[1]
lane_348_dict['time'] = time_348_list
df348 = pd.DataFrame(lane_348_dict)
df348.to_csv('lane_348_dict.csv')


lane_416_dict = {}
for j in lane_keep_offset_list:
    lane_416_dict[str(j)] = one_step(j, target_time_list[1])[0]
for k in lane_change_offset_list:
    lane_416_dict[str(k)] = one_step(k, target_time_list[1])[0]
    time_416_list = one_step(k, target_time_list[1])[1]
lane_416_dict['time'] = time_416_list
df416 = pd.DataFrame(lane_416_dict)
df416.to_csv('lane_416_dict.csv')


lane_484_dict = {}
for j in lane_keep_offset_list:
    lane_484_dict[str(j)] = one_step(j, target_time_list[2])[0]
for k in lane_change_offset_list:
    lane_484_dict[str(k)] = one_step(k, target_time_list[2])[0]
    time_484_list = one_step(k, target_time_list[2])[1]
lane_484_dict['time'] = time_484_list
df484 = pd.DataFrame(lane_484_dict)
df484.to_csv('lane_484_dict.csv')


lane_552_dict = {}
for j in lane_keep_offset_list:
    lane_552_dict[str(j)] = one_step(j, target_time_list[3])[0]
for k in lane_change_offset_list:
    lane_552_dict[str(k)] = one_step(k, target_time_list[3])[0]
    time_552_list = one_step(k, target_time_list[3])[1]
lane_552_dict['time'] = time_552_list
df552 = pd.DataFrame(lane_552_dict)
df552.to_csv('lane_552_dict.csv')


lane_62_dict = {}
for j in lane_keep_offset_list:
    lane_62_dict[str(j)] = one_step(j, target_time_list[4])[0]
for k in lane_change_offset_list:
    lane_62_dict[str(k)] = one_step(k, target_time_list[4])[0]
    time_62_list = one_step(k, target_time_list[4])[1]
lane_62_dict['time'] = time_62_list
df62 = pd.DataFrame(lane_62_dict)
df62.to_csv('lane_62_dict.csv')


lane_keep_offset_list2 = [-0.2]


lane_keep_xx_dict = {}
for t in target_time_list:

    lane_keep_xx_dict[str('time') + str(t)] = one_step(-0.25, t)[1]
    lane_keep_xx_dict[str(t)] = one_step(-0.25, t)[0]

dfx = pd.DataFrame(lane_keep_xx_dict)
dfx.to_csv('lane_x_dict.csv')